#!/bin/sh

java -Xbootclasspath/a:res -jar ConfigEditor.jar