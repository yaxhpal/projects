#!/bin/sh

java -Xbootclasspath/a:res -jar SelfIssue.jar