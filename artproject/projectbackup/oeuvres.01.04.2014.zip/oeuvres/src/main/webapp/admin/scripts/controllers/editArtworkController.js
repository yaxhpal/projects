

angular.module('oeuvres').controller('EditArtworkController', function($scope, $routeParams, $location, ArtworkResource , CategoryResource, UserResource, ArtistResource) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.artwork = new ArtworkResource(self.original);
            CategoryResource.queryAll(function(items) {
                $scope.categoriesSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.name
                    };
                    if($scope.artwork.categories){
                        $.each($scope.artwork.categories, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.categoriesSelection.push(wrappedObject);
                            }
                        });
                    }
                    return wrappedObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.email
                    };
                    if($scope.artwork.user && item.id == $scope.artwork.user.id) {
                        $scope.userSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
            ArtistResource.queryAll(function(items) {
                $scope.artistSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.firstName
                    };
                    if($scope.artwork.artist && item.id == $scope.artwork.artist.id) {
                        $scope.artistSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Artworks");
        };
        ArtworkResource.get({ArtworkId:$routeParams.ArtworkId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.artwork);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
            $location.path("/Artworks");
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.artwork.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Artworks");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Artworks");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.artwork.$remove(successCallback, errorCallback);
    };

    $scope.categoriesSelection = $scope.categoriesSelection || [];
    $scope.$watch("categoriesSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.artwork) {
            $scope.artwork.categories = [];
            $.each(selection, function(idx,selectedItem) {
                $scope.artwork.categories.push(selectedItem.value);
            });
        }
    });
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.artwork.user = selection.value;
        }
    });
    $scope.$watch("artistSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.artwork.artist = selection.value;
        }
    });

    $scope.typeList = [
    "ARTWORK",
    "SCULPTURE",
    "ANTIQUE"
    ];

    $scope.get();
});