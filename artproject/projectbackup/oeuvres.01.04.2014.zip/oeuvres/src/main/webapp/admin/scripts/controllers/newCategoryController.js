
angular.module('oeuvres').controller('NewCategoryController', function ($scope, $location, locationParser, CategoryResource ) {
    $scope.disabled = false;
    $scope.category = $scope.category || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            //$location.path('/Categorys/edit/' + id);
            $location.path("/Categorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CategoryResource.save($scope.category, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Categorys");
    };
});