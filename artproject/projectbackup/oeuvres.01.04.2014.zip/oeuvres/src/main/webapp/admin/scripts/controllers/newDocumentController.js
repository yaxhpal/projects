
angular.module('oeuvres').controller('NewDocumentController', function ($scope, $location, locationParser, DocumentResource , UserResource, ArtworkResource) {
    $scope.disabled = false;
    $scope.document = $scope.document || {};
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.email
            });
        });
    });
    
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.document.user = selection.value;
        }
    });
    $scope.artworkList = ArtworkResource.queryAll(function(items){
        $scope.artworkSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.name
            });
        });
    });
    
    $scope.$watch("artworkSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.document.artwork = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Documents/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        DocumentResource.save($scope.document, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Documents");
    };
});