
angular.module('oeuvres').controller('NewArtistController', function ($scope, $location, locationParser, ArtistResource ) {
    $scope.disabled = false;
    $scope.artist = $scope.artist || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            //$location.path('/Artists/edit/' + id);
            $location.path("/Artists");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ArtistResource.save($scope.artist, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Artists");
    };
});