

angular.module('oeuvres').controller('EditArtistController', function($scope, $routeParams, $location, ArtistResource ) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.artist = new ArtistResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Artists");
        };
        ArtistResource.get({ArtistId:$routeParams.ArtistId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.artist);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
            $location.path("/Artists");
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.artist.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Artists");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Artists");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.artist.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});