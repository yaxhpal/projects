

angular.module('oeuvres').controller('EditPurchaseHistoryController', function($scope, $routeParams, $location, PurchaseHistoryResource , ArtworkResource, UserResource) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.purchaseHistory = new PurchaseHistoryResource(self.original);
            ArtworkResource.queryAll(function(items) {
                $scope.artworkSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.name
                    };
                    if($scope.purchaseHistory.artwork && item.id == $scope.purchaseHistory.artwork.id) {
                        $scope.artworkSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.ownerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.email
                    };
                    if($scope.purchaseHistory.owner && item.id == $scope.purchaseHistory.owner.id) {
                        $scope.ownerSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/PurchaseHistorys");
        };
        PurchaseHistoryResource.get({PurchaseHistoryId:$routeParams.PurchaseHistoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.purchaseHistory);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.purchaseHistory.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PurchaseHistorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PurchaseHistorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.purchaseHistory.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("artworkSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.purchaseHistory.artwork = selection.value;
        }
    });
    $scope.$watch("ownerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.purchaseHistory.owner = selection.value;
        }
    });
    
    $scope.get();
});