angular.module('oeuvres').factory('ExhibitionResource', function($resource){
    var resource = $resource('../rest/exhibitions/:ExhibitionId',{ExhibitionId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});