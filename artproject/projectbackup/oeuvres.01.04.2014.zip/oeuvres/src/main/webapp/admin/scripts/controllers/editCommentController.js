

angular.module('oeuvres').controller('EditCommentController', function($scope, $routeParams, $location, CommentResource, UserResource, ArtworkResource) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.comment = new CommentResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.email
                    };
                    if($scope.comment.author && item.id == $scope.comment.author.id) {
                        $scope.userSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
            ArtworkResource.queryAll(function(items) {
                $scope.artworkSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.name
                    };
                    if($scope.comment.artwork && item.id == $scope.comment.artwork.id) {
                        $scope.artworkSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Comments");
        };
        CommentResource.get({CommentId:$routeParams.CommentId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.comment);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
            $location.path("/Comments");
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.comment.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Comments");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Comments");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.comment.$remove(successCallback, errorCallback);
    };

    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.comment.author = selection.value;
        }
    });

    $scope.$watch("artworkSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.comment.artwork = selection.value;
        }
    });

    $scope.get();
});