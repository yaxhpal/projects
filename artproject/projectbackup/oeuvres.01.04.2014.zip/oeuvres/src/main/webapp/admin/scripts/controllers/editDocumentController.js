

angular.module('oeuvres').controller('EditDocumentController', function($scope, $routeParams, $location, DocumentResource , UserResource, ArtworkResource) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.document = new DocumentResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.email
                    };
                    if($scope.document.user && item.id == $scope.document.user.id) {
                        $scope.userSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
            ArtworkResource.queryAll(function(items) {
                $scope.artworkSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.name
                    };
                    if($scope.document.artwork && item.id == $scope.document.artwork.id) {
                        $scope.artworkSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Documents");
        };
        DocumentResource.get({DocumentId:$routeParams.DocumentId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.document);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.document.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Documents");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Documents");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.document.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.document.user = selection.value;
        }
    });
    $scope.$watch("artworkSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.document.artwork = selection.value;
        }
    });
    
    $scope.get();
});