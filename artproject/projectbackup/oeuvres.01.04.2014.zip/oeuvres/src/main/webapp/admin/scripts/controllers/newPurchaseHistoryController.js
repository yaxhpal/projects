
angular.module('oeuvres').controller('NewPurchaseHistoryController', function ($scope, $location, locationParser, PurchaseHistoryResource , ArtworkResource, UserResource) {
    $scope.disabled = false;
    $scope.purchaseHistory = $scope.purchaseHistory || {};
    
    $scope.artworkList = ArtworkResource.queryAll(function(items){
        $scope.artworkSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.name
            });
        });
    });
    
    $scope.$watch("artworkSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.purchaseHistory.artwork = selection.value;
        }
    });
    $scope.ownerList = UserResource.queryAll(function(items){
        $scope.ownerSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.email
            });
        });
    });
    
    $scope.$watch("ownerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.purchaseHistory.owner = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/PurchaseHistorys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        PurchaseHistoryResource.save($scope.purchaseHistory, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/PurchaseHistorys");
    };
});