
angular.module('oeuvres').controller('NewLocationController', function ($scope, $location, locationParser, LocationResource , UserResource) {
    $scope.disabled = false;
    $scope.location = $scope.location || {};
    
    $scope.ownerList = UserResource.queryAll(function(items){
        $scope.ownerSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.email
            });
        });
    });
    
    $scope.$watch("ownerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.location.owner = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Locations/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        LocationResource.save($scope.location, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Locations");
    };
});