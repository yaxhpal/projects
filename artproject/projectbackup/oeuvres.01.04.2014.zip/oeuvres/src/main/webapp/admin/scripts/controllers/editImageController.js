

angular.module('oeuvres').controller('EditImageController', function($scope, $routeParams, $location, ImageResource , ArtworkResource) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.image = new ImageResource(self.original);
            ArtworkResource.queryAll(function(items) {
                $scope.artworkSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.name
                    };
                    if($scope.image.artwork && item.id == $scope.image.artwork.id) {
                        $scope.artworkSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Images");
        };
        ImageResource.get({ImageId:$routeParams.ImageId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.image);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
            $location.path("/Images");
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.image.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Images");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Images");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.image.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("artworkSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.image.artwork = selection.value;
        }
    });
    
    $scope.get();
});