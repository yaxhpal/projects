

angular.module('oeuvres').controller('EditExhibitionController', function($scope, $routeParams, $location, ExhibitionResource ) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.exhibition = new ExhibitionResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Exhibitions");
        };
        ExhibitionResource.get({ExhibitionId:$routeParams.ExhibitionId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.exhibition);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.exhibition.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Exhibitions");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Exhibitions");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.exhibition.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});