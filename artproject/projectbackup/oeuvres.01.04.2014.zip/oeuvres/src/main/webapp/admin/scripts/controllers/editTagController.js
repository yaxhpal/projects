

angular.module('oeuvres').controller('EditTagController', function($scope, $routeParams, $location, TagResource , UserResource, ArtworkResource) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.tag = new TagResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.email
                    };
                    if($scope.tag.user && item.id == $scope.tag.user.id) {
                        $scope.userSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
            ArtworkResource.queryAll(function(items) {
                $scope.artworksSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.name
                    };
                    if($scope.tag.artworks){
                        $.each($scope.tag.artworks, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.artworksSelection.push(wrappedObject);
                            }
                        });
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Tags");
        };
        TagResource.get({TagId:$routeParams.TagId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.tag);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
            $location.path("/Tags");
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.tag.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Tags");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Tags");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.tag.$remove(successCallback, errorCallback);
    };

    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.tag.user = selection.value;
        }
    });
    $scope.artworksSelection = $scope.artworksSelection || [];
    $scope.$watch("artworksSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.tag) {
            $scope.tag.artworks = [];
            $.each(selection, function(idx,selectedItem) {
                $scope.tag.artworks.push(selectedItem.value);
            });
        }
    });
    $scope.get();
});