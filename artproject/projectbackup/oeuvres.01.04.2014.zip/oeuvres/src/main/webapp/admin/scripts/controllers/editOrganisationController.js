

angular.module('oeuvres').controller('EditOrganisationController', function($scope, $routeParams, $location, OrganisationResource ) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.organisation = new OrganisationResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Organisations");
        };
        OrganisationResource.get({OrganisationId:$routeParams.OrganisationId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.organisation);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
            $location.path("/Organisations");
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.organisation.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Organisations");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Organisations");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.organisation.$remove(successCallback, errorCallback);
    };
    
    $scope.typeList = [
        "ADMIN",  
        "GALLARY",  
        "PERSONAL",  
        "OTHER"  
    ];
    
    $scope.get();
});