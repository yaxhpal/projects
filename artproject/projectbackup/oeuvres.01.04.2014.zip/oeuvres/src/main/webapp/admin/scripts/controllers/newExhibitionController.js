
angular.module('oeuvres').controller('NewExhibitionController', function ($scope, $location, locationParser, ExhibitionResource ) {
    $scope.disabled = false;
    $scope.exhibition = $scope.exhibition || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Exhibitions/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ExhibitionResource.save($scope.exhibition, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Exhibitions");
    };
});