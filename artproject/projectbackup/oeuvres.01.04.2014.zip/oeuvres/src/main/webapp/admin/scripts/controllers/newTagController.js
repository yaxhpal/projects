
angular.module('oeuvres').controller('NewTagController', function ($scope, $location, locationParser, TagResource, UserResource, ArtworkResource) {
    $scope.disabled = false;
    $scope.tag = $scope.tag || {};

    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.email
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.tag.user = selection.value;
        }
    });

    $scope.artworksList = ArtworkResource.queryAll(function(items){
        $scope.artworksSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.name
            });
        });
    });
    $scope.$watch("artworksSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.tag.artworks = [];
            $.each(selection, function(idx,selectedItem) {
                $scope.tag.artworks.push(selectedItem.value);
            });
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            //$location.path('/Tags/edit/' + id);
            $location.path("/Tags");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TagResource.save($scope.tag, successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Tags");
    };
});