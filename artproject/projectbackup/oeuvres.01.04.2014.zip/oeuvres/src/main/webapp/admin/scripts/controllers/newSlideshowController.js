
angular.module('oeuvres').controller('NewSlideshowController', function ($scope, $location, locationParser, SlideshowResource, UserResource, ArtworkResource) {
    $scope.disabled = false;
    $scope.slideshow = $scope.slideshow || {};

    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.email
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.slideshow.user = selection.value;
        }
    });

    $scope.artworksList = ArtworkResource.queryAll(function(items){
        $scope.artworksSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.name
            });
        });
    });
    $scope.$watch("artworksSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.slideshow.artworks = [];
            $.each(selection, function(idx,selectedItem) {
                $scope.slideshow.artworks.push(selectedItem.value);
            });
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            //$location.path('/Slideshows/edit/' + id);
            $location.path("/Slideshows");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        SlideshowResource.save($scope.slideshow, successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Slideshows");
    };
});