

angular.module('oeuvres').controller('EditLocationController', function($scope, $routeParams, $location, LocationResource , UserResource) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.location = new LocationResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.ownerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.email
                    };
                    if($scope.location.owner && item.id == $scope.location.owner.id) {
                        $scope.ownerSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Locations");
        };
        LocationResource.get({LocationId:$routeParams.LocationId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.location);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.location.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Locations");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Locations");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.location.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("ownerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.location.owner = selection.value;
        }
    });
    
    $scope.get();
});