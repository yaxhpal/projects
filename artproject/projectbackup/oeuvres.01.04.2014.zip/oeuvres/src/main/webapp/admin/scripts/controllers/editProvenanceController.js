

angular.module('oeuvres').controller('EditProvenanceController', function($scope, $routeParams, $location, ProvenanceResource , ArtworkResource) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.provenance = new ProvenanceResource(self.original);
            ArtworkResource.queryAll(function(items) {
                $scope.artworkSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.name
                    };
                    if($scope.provenance.artwork && item.id == $scope.provenance.artwork.id) {
                        $scope.artworkSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Provenances");
        };
        ProvenanceResource.get({ProvenanceId:$routeParams.ProvenanceId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.provenance);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.provenance.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Provenances");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Provenances");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.provenance.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("artworkSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.provenance.artwork = selection.value;
        }
    });
    
    $scope.get();
});