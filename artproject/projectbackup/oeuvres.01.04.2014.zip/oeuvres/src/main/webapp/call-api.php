<?php
error_reporting(0);

header("Content-type: application/json");

$user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.8.0.9) Gecko/20061206 Firefox/1.5.0.9';

$header = array(
	"Content-Type: application/json",
    "Accept: text/xml,application/xml,application/xhtml+xml, text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5",
    "Accept-Language: ru-ru,ru;q=0.7,en-us;q=0.5,en;q=0.3",
    "Accept-Charset: windows-1251,utf-8;q=0.7,*;q=0.7",
    "Keep-Alive: 300"
);

$request = $_GET['request'];$delete = $_GET['delete'];

$ch = curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);
if ($request=="/rest/app/comment" || $request=="/rest/app/tag/addArtwork" || $request=="/rest/app/tag/removeArtwork" || $request=="/rest/app/slideshow" || $request=="/rest/app/slideshow/addArtwork" || $request=="/rest/app/login" || $request=="/rest/app/slideshow/removeArtwork"){
	$fields_string = $_GET['data'];
	$fields_string = str_replace('\"','"',$fields_string);
	curl_setopt($ch, CURLOPT_POSTFIELDS,  $fields_string);
	curl_setopt($ch, CURLOPT_POST, 1);	
}
if ($delete=="yes"){
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
}
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
//curl_setopt($ch, CURLOPT_URL, "http://test.oeuvr.es/rest/app/13");
curl_setopt($ch, CURLOPT_URL, "http://test.art.zennstrom.com".$request);
//curl_setopt($ch, CURLOPT_URL, "http://oeuvres.dev:8888".$request);

//test

$content = curl_exec($ch);
echo substr($content, curl_getinfo($ch,CURLINFO_HEADER_SIZE));
curl_close($ch);
?>