'use strict';

oeuApp.directive('artworkLoop', [function(){
	return {
		restrict: 'E',
		templateUrl: 'views/artworkLoop.html',
		replace: true,
		controller: function($scope, $rootScope, opts, $location, $timeout, $cookieStore, dataDelegate){

			$scope.scrollTO = null;
			$scope.scrollTO_short = null;
			$scope.resizeTO = null;
			$scope.touchTO = null;
			$scope.touched = false;
			$scope.imgHeld = false;
			$scope.toArtwork = false;

			$scope.viewToggle = opts.options.viewToggle;
			if($scope.isInject){
				$scope.viewToggle = 'grid';
			}

			$scope.removeArtwork = function(id, e){
				if(e){
					e.stopPropagation();
				}
				dataDelegate.detachArtwork(id, $scope.filterID, function(d){
					$rootScope.$apply(function(){
						for (var i=0;i<slideshowsGB.length;i++){
							if (slideshowsGB[i].id==$scope.filterID){
								slideshowsGB[i].artworks = d.artworks;
								var newArtworks = _.filter(artworksGB, function(obj,key){ return _.contains(d.artworks, obj.id); });
								$scope.artworks = _.sortBy(newArtworks, function(obj){ return obj.year; });
								var slideshowTitle = $scope.title;
								setTimeout(function() {$('#drawerRight .menu li a').removeClass('selected');}, 100);
								setTimeout(closeDrawers, 250);
								showAlert('removeedToSlideshow', slideshowTitle);
								setTimeout(function(){
									$scope.updateGrid();
								}, 10);
								break;
							}
						}
					});
				});
			}

			$scope.exitSlideshow = function(){
				if(!$scope.toArtwork && opts.getOption('fromSlideshow')){
					opts.updateOption('fromSlideshow', false);
				}
			}
			
			$scope.updateGrid = function(){

				if($scope.$grid && $scope.$grid.data('isotope')){
					$scope.$grid.isotope('destroy');
					$scope.$grid.find('.image').swipe('destroy');
					setTimeout(function(){
						$scope.setUpIso();
					}, 10);
				}
			}

			$scope.titleLength = function(string){
				var str;
				var maxLength = 54;
				if(string.length > maxLength){
					str = string.substr(0, maxLength);
					str += '(...)'
				} else {
					str = string;
				}
				
				return str;
			}

			$scope.hasLoaded = function(){
				$scope.$grid = $scope.$el.find('ul:eq(0)');
				
				$scope.setUpIso();
				
				$scope.$grid.find('li').each(function(){
					$(this).swipe({
				      	tap: function(event) { $scope.triggerPage(event); },
				        hold: function(event) { $scope.slideshowTrigger(event); },
				        //doubleTap: function(event) { $scope.changeView(event); },
				        longTapThreshold: 300,
				        allowPageScroll: 'vertical',
				       	excludedElements: 'button, input, select, textarea, .noSwipe',
				        swipeStatus:function(event, phase, direction, distance, duration, fingers){
				        	if(phase=='end'){
				        		setTimeout(function(){
					        		$scope.imgHeld = false;
					        	}, 500);
				        	}
				        }
				    });
				});

				setTimeout(function(){
					$('#pageContent').removeClass('noTransGrid');
				}, 301);
			}

			$scope.setUpIso = function(){
				$scope.$grid.isotope({});
				//$scope.$grid.imagesLoaded(function(){
					$scope.resize();
					var time = 0;
					if($scope.callback){ time = 600; }
					setTimeout(function(){
						$('#page-content').show();
						if($scope.callback){ $scope.callback(); }
						if(!$scope.isInject && !$scope.noArtworks){ $scope.yearNavBuild(); }
						hideLoading();
					}, time);
				//});
			}
			
			$scope.evalImgs = function(){
				if(!$scope.$grid){ return; }
				var scrollTop = $(window).scrollTop();
				var windowHeight = $(window).height();
				$scope.$grid.find('li').each(function(){
					var offset = $(this).offset().top;
					var height = $(this).height();
					var $img = $('.image', this);
					if(scrollTop < offset+height && scrollTop+windowHeight > offset-height){
						var imgSrc = $img.attr('img-src');
						var i = new Image();
						i.src = imgSrc;
						$img.html(i);
						$img.imagesLoaded(function(){
							$img.addClass('in');
						});
					} else {
						$img.html('').removeClass('in');
					}
				});
			}

			/*$scope.resize = function(){
				if($scope.resizeTO){ clearTimeout($scope.resizeTO); }
				//var w = $scope.$grid.width();
				//var colW = w/4;
				$scope.resizeTO = setTimeout(function(){
					if($scope.$grid && $scope.$grid.data('isotope')){
						$scope.$grid.isotope('reLayout');
					}
				}, 300);
			}*/

			$scope.resize = function(){
				if($scope.resizeTO){ clearTimeout($scope.resizeTO); }
				$scope.resizeTO = setTimeout(function(){
					if($scope.$grid){
						if($scope.$grid.closest('.objectContainer').hasClass('grid')){
							var imgWidth = $scope.$grid.find('li:eq(0) .inner').width();
							var $lis = $scope.$grid.find('li');
							$lis.each(function(){
								var $img = $('.image', this);
								var w = $img.attr('img-w');
								var h = $img.attr('img-h');
								var ratio = h/w;
								$img.css({'width': imgWidth, 'height': imgWidth*ratio});
							});
						}
						if($scope.$grid.data('isotope')){
							$scope.$grid.isotope('reLayout');
							setTimeout(function(){
								$scope.evalImgs();
							}, 300);
						}
					}
				}, 300);
			}

			$scope.yearNavBuild = function(){
				var fY, lY;
				$scope.$el.find('li').each(function(){
					var year = parseInt($(this).attr('year-ref'));
					if((fY!=0 && !fY) || year < fY){
						fY = year;
					}
					if(!lY || year > lY){
						lY = year;
					}
				});
				var diff = 100;
				var nYs = Math.ceil((lY - fY)/diff);
				nYs+=1;
				
				$('#yearNav').html('');
				for(var i = 0; i < nYs; i++){
					$('#yearNav').append('<li><span class="year">'+(fY+(i*diff))+'</span></li>');
				}
				$('#yearNav').append('<div class="cYCont"><div class="cY"></div></div><div class="cYRange"></div>');
				$('#yearNav').css({'margin-top':-(16*(nYs/2))+60});
				$('#yearNav .cYCont').css({'height':(16*nYs)-10})


				$scope.firstYear = fY;
				$scope.lastYear = lY;
			}

			$scope.changeView = function(e){
				e.stopPropagation();
				if($scope.isInject){ return; }
				if(opts.options.viewToggle == 'grid'){
					opts.options.viewToggle = 'list';
					$scope.$grid.find('li .image').attr('style', '');
				} else {
					opts.options.viewToggle = 'grid';
				}
				$scope.viewToggle = opts.options.viewToggle;
				$scope.$el.removeClass('grid list').addClass($scope.viewToggle);
				$scope.scrollFunc();
				$scope.$grid.isotope('reLayout');
				$scope.resize();
			}

			$scope.gestureHandler = function(e){
				var scale = e.originalEvent.scale;
				if(scale > 1.5 && opts.options.viewToggle == 'list'){
					$scope.changeView(e);
				} else if(scale < 0.5 && opts.options.viewToggle == 'grid'){
					$scope.changeView(e);
				}
			}

			$scope.scrollFunc = function(){
				if($scope.scrollTO){ clearTimeout($scope.scrollTO); }
				
				$('#yearNav').addClass('scrollActive');

				var fY, lY;
				var fYs = [],
					lYs = [];
				var scrollPos = $(window).scrollTop();
				if(scrollPos<0){
					scrollPos = 0;
				}
				var windowHeight = $(window).height();
				$scope.$el.find('li').each(function(){
					var offsetTop = $(this).offset().top;
					var height = $(this).height();
					if(offsetTop+(height*0.9)>scrollPos){
						fYs.push($(this).attr('year-ref'));
					}
					if(offsetTop+(height/2)<scrollPos+windowHeight){
						lYs.push($(this).attr('year-ref'));
					}
				});
				_.each(fYs, function(_i){
					if(!fY || _i < fY){
						fY = _i;
					}
				});
				_.each(lYs, function(_i){
					if(!lY || _i > lY){
						lY = _i;
					}
				});
				var yNH = (lY-fY)/100*16;
				var yFP = (fY-$scope.firstYear)/100*16;
				$('#yearNav .cY').css({'height': yNH, '-webkit-transform':'translateY('+yFP+'px)'})

				var yearRangeHtml = fY+' - '+lY;
				if(fY==lY){
					yearRangeHtml = fY;
				}
				$('#yearNav .cYRange').html(yearRangeHtml).css({'-webkit-transform':'translateY('+(yFP+(yNH/2))+'px)'});
				
				$scope.scrollTO = setTimeout(function(){
					if(!$scope.touched){
						$('#yearNav').removeClass('scrollActive');
					}
				}, 500);
			}

			$scope.viewportScroll = function(){
				if($scope.scrollTO_short){ clearTimeout($scope.scrollTO_short); }
				$scope.scrollTO_short = setTimeout(function(){
					$scope.evalImgs();
				}, 100);
			}

			var lScroll = 0;
			var lastYearTar = 0;

			$scope.scrollTo = function(e, force){
				var now = +new Date;
				if(now-lScroll<200 && !force){ return; }
				lScroll = now;
				e.preventDefault();
				var yNT = $('#yearNav').offset().top;
				var mY;
				if($('body').hasClass('hasTouch')){
					mY = e.originalEvent.touches[0].pageY;
				} else {
					mY = e.pageY;
				}
				var rMY = mY-yNT;
				var maxYNH = ($scope.lastYear-$scope.firstYear)/100*16;
				if(rMY<0){
					rMY = 0;
				} else if(rMY > maxYNH){
					rMY = maxYNH;
				}
				var yearTar = Math.round(rMY/16*100);
				yearTar += $scope.firstYear;
				if(lastYearTar == yearTar){ return; }
				lastYearTar = yearTar;
				var diff;
				var aYearTar;
				$scope.$el.find('li').each(function(){
					var year = parseInt($(this).attr('year-ref'));
					var tDiff = Math.abs(yearTar-year);
					if((diff!=0 && !diff) || tDiff < diff){
						diff = tDiff;
						aYearTar = year;
					}
				});
				scrollToElement($scope.$el.find('li[year-ref="'+aYearTar+'"]:eq(0)'), 'middle');
			}

			$scope.mouseDownFunc = function(e){
				if($scope.touchTO){
					clearTimeout($scope.touchTO);
				}
				$scope.touched = true;
				$scope.touchTO = setTimeout(function(){
					$('#yearNav').addClass('touchActive');
				}, 200);
				$(this).addClass('scrollActive');
				$scope.scrollTo(e, $scope.$el);
			}

			$scope.mouseMoveFunc = function(e){
				if(!$scope.touched){ return; }
				$scope.scrollTo(e, $scope.$el);
			}

			$scope.mouseUpFunc = function(){
				if(!$scope.touched){ return; }
				if($scope.touchTO){
					clearTimeout($scope.touchTO);
				}
				$('#yearNav').removeClass('touchActive');
				$scope.touched = false;
				//$(window).trigger('scroll');
			}

			$scope.slideshowTrigger = function(event){
				var el;
				if($('body').hasClass('hasTouch')){
					el = event.target;
					$scope.imgHeld = true;
				} else {
					el = event.toElement;
					$scope.$grid.find('.image').swipe('disable');
					$scope.$grid.find('.image').swipe('enable');
				}

				var $el = $(el);
				var id = $el.closest('li').attr('data-ref');
				
				addToSlideshow(id);
				return false;
			}

			$scope.triggerPage = function(event){
				if($scope.imgHeld){ return; }
				//alert('x');
				//return;
				
				var el;
				if($('body').hasClass('hasTouch')){
					el = event.target;
				} else {
					el = event.toElement;
				}
				var $el = $(el);
				if($el.hasClass('remove') && $('body').hasClass('hasTouch')){
					var artworkID = $el.attr('art-id');
					//alert(artworkID);
					$scope.removeArtwork(artworkID);
					return;
				}
				var id = $el.closest('li').attr('data-ref');
				$scope.toArtwork = true;
				$scope.gotoPage(id);
				return false;
			}

			$scope.gotoPage = function(id){
				if (id>0 && !$('#contextMenu').hasClass('isVisible')){
					var vlist = _.pluck($scope.artworks, 'id');
					$cookieStore.put('artworks8only',vlist.join(','));
					$location.path('object/'+id);
					$scope.$apply();
				}
				
			};

			$scope.pageForward = function(locat) {
				$location.path(locat);
			};
		
		},
		link: function($scope, element, attr){
			
			$scope.$el = $(element);

			$(window).on('resize', $scope.resize);
			$(window).on('scroll', $scope.viewportScroll);

			if(!$scope.isInject){

				$(window).on('scroll', $scope.scrollFunc);
				$('body').addClass('yearScroll');
				$('#pageContent').on('dblclick', $scope.changeView);

				if($('body').hasClass('hasTouch')){
					$('#yearNav').on('touchstart', $scope.mouseDownFunc);
					$('body').on('touchmove', $scope.mouseMoveFunc);
					$('body').on('touchend', $scope.mouseUpFunc);
					$scope.$el.on('gestureend', $scope.gestureHandler);
				} else {
					$('#yearNav').on('mousedown', $scope.mouseDownFunc);
					$('body').on('mousemove', $scope.mouseMoveFunc);
					$(document).on('mouseup', $scope.mouseUpFunc);
				}
			} else {
				$scope.$el.on('scroll', $scope.viewportScroll);
			}

			$scope.$on('$destroy', function(){

				$(window).off('resize', $scope.resize);
				$(window).off('scroll', $scope.scrollFunc);
				$(window).off('scroll', $scope.viewportScroll);
				$('#pageContent').off('dblclick', $scope.changeView);

				$scope.exitSlideshow();

				if(!$scope.isInject){
					$('#yearNav').off('mousedown', $scope.mouseDownFunc);
					if($('body').hasClass('hasTouch')){
						$('#yearNav').off('touchstart', $scope.mouseDownFunc);
						$('body').off('touchmove', $scope.mouseMoveFunc);
						$('body').off('touchend', $scope.mouseUpFunc);
						$scope.$el.off('gestureend', $scope.gestureHandler);
					} else {
						$('#yearNav').off('mousedown', $scope.mouseDownFunc);
						$('body').off('mousemove', $scope.mouseMoveFunc);
						$(document).off('mouseup', $scope.mouseUpFunc);
					}
					
				} else {

					$scope.$el.off('scroll', $scope.viewportScroll);
				}

				$scope.$grid.find('.image').swipe('destroy');
				$('#yearNav').html('').removeClass('scrollActive');
				$('body').removeClass('yearScroll');
			});
		


			if($scope.noArtworks){
				$scope.hasLoaded();
			}
		}
	}
}] );