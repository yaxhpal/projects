'use strict';

oeuApp.service('categories', function($rootScope,dataDelegate){
	return;
	this.items 	= dataDelegate.get('categories');
	this.once	= false;
	this.init 	= function(){
		if (!this.once){
			this.once	= true;
			var artworks = dataDelegate.get('artworks');
			_.each(this.items, function(obj,key){
				var arts = _.filter(artworks, function(artObj){return _.contains(artObj.categories, obj.id);});
				if (arts.length){
					obj.image = (arts[0].images.length)?arts[0].images[0]:'';
					obj.totalArts = arts.length;
				}else{
					obj.image = '';
					obj.totalArts = 0;
				}
				if (obj.image==""){
					obj.image = 'default_category';
				}
				arts = null;
			});
			artworks = null;
		}
		

	}
})