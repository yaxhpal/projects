'use strict';

oeuApp.factory('Auth', function($http, $cookieStore){
    var accessLevels = routingConfig.accessLevels
        , userRoles = routingConfig.userRoles
        , currentUser = $cookieStore.get('user') || {id:-1, username: '', role: userRoles.public };
    $cookieStore.remove('user');

    function changeUser(user) {
        _.extend(currentUser, user);
    };
    return {
        authorize: function(accessLevel, role) {
            if(role === undefined)
                role = currentUser.role;
            return accessLevel.bitMask & role.bitMask;
        },
        isLoggedIn: function(user) {
            if(user === undefined)
                user = currentUser;
            return user.role.title == userRoles.user.title || user.role.title == userRoles.admin.title;
        },
        login: function(user, success, error) {

        	if (user.username=="demo@demo.com" && user.password=="demo"){
                //user.role = {bitMask:4, title:'admin'};
                //changeUser(user);
                //success(user);
        	}else{
        		error();
        	}
        },
        logout: function(success, error) {
                changeUser({
                    username: '',
                    role: userRoles.public
                });
                success();
        },
        accessLevels: accessLevels,
        userRoles: userRoles,
        user: currentUser
    }

});