'use strict';

oeuApp.controller('categoryController', function($scope, $route,$location,$cookieStore, artworks, categories, dataDelegate){
	$('#loading').removeClass('isHidden');
	artworks.init();categories.init();dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	//if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
	pageContentObj.removeClass('galleryView');$('#removeFromSlideshow').css('display','none');
	var cid = $route.current.params.categoryId;
	if (cid !== undefined && cid!="" && cid>0){
		var category 	= _.find(categories.items, function(obj, key){ return obj.id == cid;});
		if (category!==undefined && category.id>0){
			$scope.categoryTitle = category.name;
			$scope.artworks = _.filter(artworks.items, function(obj, key){ return _.contains(obj.categories, cid*1);});
		}else{
			$location.path('/');
		}
	}else{
		$scope.categoryTitle = "";
		var atype = 0;
		if ($location.path().indexOf('sculptures')>-1){
			atype = 1;
		}else if ($location.path().indexOf('antiques')>-1){
			atype = 2;
		}
		$scope.artworks = _.filter(artworks.items, function(obj,key) {return obj.type == atype;});
	}
	$scope.setLoading = function(){
		//$('#artistArtworks').find('img.lazy').lazyload({effect : "fadeIn",threshold : 50});$(window).resize();
		var $container = $('#artistArtworks .grid ul');
		$container.imagesLoaded(function(){
			$.when(gridViewSet()).then(function(){
				hideLoading();
				pageContentObj.show();
			});
		});
	};
	$scope.gotoPage 			= function(id){
		if (id>0 && !$('#contextMenu').hasClass('isVisible')){
			var vlist = _.pluck($scope.artworks, 'id');
			$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+id);
		}
		
	};
	$scope.pageForward = function(locat) {
		$location.path(locat);
	};
});


oeuApp.directive('categoryallRenderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
           if ($scope.$last === true) {
                element.ready(function () {
                    $scope.setLoading();
                });
           }
		}
	};
});