'use strict';

oeuApp.directive('locationsList', function($timeout, $location, $compile, dataDelegate, $rootScope){
	return {
		restrict: 'E',
		templateUrl: 'views/locationsList.html',
		scope: {},
		controller: function($scope){
			var updateLocations = function(){
				var locations = [];
				_.each(locationsGB, function(_i){
					if(!_.findWhere(locations, {location: _i.location, country: _i.country})){
						_i.string = '';
						if(_i.location){
							_i.string += _i.location;
						}
						if(_i.country){
							_i.string += ', '+_i.country;
						}
						if(_i.string.length){
							locations.push(_i);
						}
					}
				});
				$scope.locations = locations;
			}

			dataDelegate.registerCallbacks(updateLocations);

			$scope.updateSelect = function(){
				//console.log($scope.location);
				//updateLocations();
				var string = $scope.location.location;
				if($scope.location.country){
					string+='&country='+$scope.location.country;
				}
				$location.path('browse/location/'+string);
				closeDrawers();
				$timeout(function(){
					$scope.location = '';
				}, 200);
			}
		},
		link: function($scope, element, attr){
		}

	}
} );