'use strict';

oeuApp.service('opts', function($rootScope){
	
	this.options = {
		viewToggle: 'grid',
		artworksArr: [],
		fromSlideshow: false
	}

	this.updateOption = function(option, value){
		this.options[option] = value;
	}

	this.getOption = function(option){
		return this.options[option];
	}

});