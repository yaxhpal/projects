'use strict';

oeuApp.service('locations', function($rootScope,dataDelegate){
	this.items 	= dataDelegate.get('locations');
	this.once	= false;
	this.init 	= function(){
		if (!this.once){
			this.once	= true;
		}
	}
})