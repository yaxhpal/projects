'use strict';

oeuApp.controller('originController', function($scope, $route,$location,$cookieStore, artworks, dataDelegate){
	$('#loading').removeClass('isHidden');
	artworks.init();dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	//if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
	pageContentObj.removeClass('galleryView');$('#removeFromSlideshow').css('display','none');
	var cid = $route.current.params.originId;
	if (cid !== undefined && cid!=""){
		$scope.categoryTitle = cid.charAt(0).toUpperCase() + cid.slice(1);
		$scope.artworks = _.filter(artworks.items, function(obj, key){
			return obj.origin.toLowerCase() == cid;
		});
	}else{
		$location.path('/');
	}
	$scope.setLoading = function(){
		var $container = $('#artistArtworks .grid ul');
		$container.imagesLoaded(function(){
			$.when(gridViewSet()).then(function(){
				hideLoading();
				pageContentObj.show();
			});
		});
	};
	$scope.gotoPage = function(id){
		if (id>0 && !$('#contextMenu').hasClass('isVisible')){
			var vlist = _.pluck($scope.artworks, 'id');
			$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+id);
		}
		
	};
	$scope.pageForward = function(locat) {
		$location.path(locat);
	};
});

oeuApp.directive('categoryallRenderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
           if ($scope.$last === true) {
                element.ready(function () {
                    $scope.setLoading();
                });
           }
		}
	};
});