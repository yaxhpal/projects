'use strict';

oeuApp.directive('featuresList', function($timeout){
	return {
		restrict: 'E',
		templateUrl: 'views/featuresList.html',
		scope: {},
		controller: function($scope, artworks){
			artworks.init();
			//categories.init();
			var categoryData = [{
				id: 0,
				title: 'Artworks',
				img: 26
			}, {
				id: 1,
				title: 'Sculptures',
				img: 106
			}];
			var counts = _.countBy(artworks.items, function(obj){
				return obj.category
			});
			var categoryArr = [];
			_.each(categoryData, function(_i){
				var count = counts[_i.id];
				categoryArr.push({
					id: _i.id,
					name: _i.title,
					image: _i.img,
					totalArts: count
				});
			});
			$scope.categories = categoryArr;
			/*if (categories.items.length>4){
				var newList 	= categories.items.slice(0);
				$scope.categories   = _.flatten(newList.toRandom(4));
				newList = null;
			}else{
				$scope.categories 	= categories.items;
			}*/
			$scope.init_slider 	= function(){
				$timeout(function () {
					$('#features').flexslider({
					    animation: "slide",
					    keyboard: true,
					    controlNav: true,
						directionNav: false,
						slideshow: false,
						startAt: 0,
						animationLoop: true,
						pauseOnHover: false,
						start: function(slider) {
							fitFeatureHeadings();
							},
						before: function(slider) {
							fitFeatureHeadings();
							},
						after: function(slider) {
							//
							}
						});
				}, 1);
			}
		},
		link: function($scope,element, attr){
		}

	}
} );

oeuApp.directive('featuresRenderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
           if ($scope.$last === true) {
                element.ready(function () {                    
                    $scope.init_slider();
                });
           }
		}
	};
});