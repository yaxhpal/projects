'use strict';

oeuApp.service('artworks', function($rootScope,dataDelegate){
	this.items	= dataDelegate.get('artworks');
	this.once	= false;
	this.init 	= function(){
		if (!this.once){
			this.once = true;
			var artists = dataDelegate.get('artists');
			_.each(this.items, function(obj,key){
				var arts 	= _.find(artists, function(art){ return art.id==obj.artist; });
				if (arts){
					obj.artistname = arts.firstName + ' ' + arts.lastName;
				}else{
					obj.artistname = '';
				}
				arts 	= null;
			});
			artists 	= null;
		}
	};
	this.get = function(artworkid){
		return _.find(this.items, function(obj,key){ return obj.id == artworkid;})
	};
	this.getIndex = function(artworkid){
		var ret = -1;
		_.each(this.items,function(obj,i){if(obj.id==artworkid){ret=i}});
		return ret;
	}

})