function init(){
	var arr = [];
	$.ajax({
		type: 'GET',
		url: 'call-api.php?request=/rest/app/13',
		success: function(data){
			var artworks = data[0].values;
			var tC = artworks.length;
			_.each(artworks, function(obj){
				var id = obj.images[0];
				var i = new Image();
				i.src = '//bkkr.co/nz/artApp/images/artworks/'+id+'h.jpg';
				$(i).load(function(){
					arr.push({
						width: i.width,
						height: i.height,
						id: id
					});
					if(tC==arr.length){
						append(arr);
					}
				});
			});
		}
	});
}

function append(arr){
	var orderedArr = _.sortBy(arr, function(obj){
		return obj.id;
	});
	$('body').html('');
	_.each(orderedArr, function(obj){
		$('body').append(obj.id+', '+obj.width+', '+obj.height+'<br />')
	});
}

$(document).ready(function(){
	init();
});