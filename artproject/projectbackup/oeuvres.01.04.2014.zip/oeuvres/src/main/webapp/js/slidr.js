// BKKR Slidr
// Author kwang-su@bkkr.co


(function($) {

	$.fn.slidr = function( options ) {

		var ease = "cubic-bezier(0.250,0.100,0.250,1.000)", easeOutExpo = "cubic-bezier(0.190, 1.000, 0.220, 1.000)", transEnd = "webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend";

		$.fn.slidr.defaults = {
			arr: [],
			easing : easeOutExpo,
			duration : 500,
			startAt: 1,
			autostart: false,
			click: true,
			$scope: null,
			keyboard: true,
			counter: true,
			delay: 2000,
			looping: false,
			touch: false,
			start: function(){},
			before: function(){},
			after: function(){},
			end: function(){}
		};

		opts = $.extend( {}, $.fn.slidr.defaults, options);

		return this.each(function() {

			slidrArr = opts.arr;
			slider = $(this);
			slider.attr("data-order", opts.startAt);
			sliderWrapper = slider.parent();
			sliderWidth = $(window).width();
			slideNum = slidrArr.length;
			startingAt = opts.startAt - 1;
			slider.wrap(".slidr-container");
			sliderWrapper.css({"overflow": "hidden"});
			slider.css({
				"width": sliderWidth*4 + "px",
				"cursor": "pointer"
			});

			if (opts.startAt == 1) {
				lastSlide = '<li><img src="' + slidrArr[slideNum-1].imgURL + '" h="'+ slidrArr[slideNum-1].height +'" /></li>';
				slider.append(lastSlide);
				for (var i=0; i<2; i++) {
					var slideStr = '<li><img src="' + slidrArr[i].imgURL + '" h="'+ slidrArr[i].height +'" /></li>';
					slider.append(slideStr);
				}
			} else if (opts.startAt < slideNum) {
				for (var i=0; i<3; i++) {
					var slideStr = '<li><img src="' + slidrArr[opts.startAt+i-2].imgURL + '" h="'+ slidrArr[opts.startAt+i-2].height +'" /></li>';
					slider.append(slideStr);
				}
			} else {
				for (var i=0; i<2; i++) {
					var slideStr = '<li><img src="' + slidrArr[slideNum+i-2].imgURL + '" h="'+ slidrArr[slideNum+i-2].height +'" /></li>';
					slider.append(slideStr);
				}
				firstSlide = '<li><img src="' + slidrArr[0].imgURL + '" h="'+ slidrArr[0].height +'" /></li>';
				slider.append(firstSlide);
			}
			var position = -100/4;
			slider.css({
				"-webkit-transform": "translate3d(" + position + "%, 0, 0)",
				"-moz-transform": "translate3d(" + position + "%, 0, 0)",
				"-ms-transform": "translate3d(" + position + "%, 0, 0)",
				"transform": "translate3d(" + position + "%, 0, 0)"
			});
			slider.children("li").css({"width": 100/4 + "%"});
			slider.addClass("slidr");
			dynamicHeights();
			// Title settings
			/*slider.before("<div class='projectCover'></div>");
			$(".projectCover").append("<h3 class='projectTitle'></h3>");
			$(".projectCover").append("<p class='projectDesc'></p>");
			$(".projectTitle").append(slidrArr[0].title);
			$(".projectDesc").append(slidrArr[0].desc);*/

			// Background cover
			function cover() {
				slider.children("li").css("-webkit-background-size", "cover");
				slider.children("li").css("-moz-background-size", "cover");
				slider.children("li").css("-o-background-size", "cover");
				slider.children("li").css("background-size", "cover");
				slider.children("li").css("background-position", "50% 50%");
				slider.children("li").css("background-repeat", "no-repeat");
			}

			// Sliding settings
			var sliding = false;
			function goToPrevious() {
				sliding = true;
				var position = 0;
				var order = slider.attr("data-order");
				//if (order > 1) {
					slider.css({
						"-webkit-transform": "translate3d(" + position + "%, 0, 0)",
						"-moz-transform": "translate3d(" + position + "%, 0, 0)",
						"-ms-transform": "translate3d(" + position + "%, 0, 0)",
						"transform": "translate3d(" + position + "%, 0, 0)",
						"-webkit-transition": "all " + opts.duration + "ms " + opts.easing + "",
						"-moz-transition": "all " + opts.duration + "ms " + opts.easing + "",
						"-ms-transition": "all " + opts.duration + "ms " + opts.easing + "",
						"transition": "all " + opts.duration + "ms " + opts.easing + ""
					});
				//}
				if (transEnd) {
					var newOrder = parseInt(order)-1;
					if(newOrder <= 0){ newOrder = slideNum; }
					slider.attr("data-order", newOrder);
					count();
					setTimeout(function() {
						var position = -100/4;
						slider.css({
							"-webkit-transform": "translate3d(" + position + "%, 0, 0)",
							"-moz-transform": "translate3d(" + position + "%, 0, 0)",
							"-ms-transform": "translate3d(" + position + "%, 0, 0)",
							"transform": "translate3d(" + position + "%, 0, 0)",
							"-webkit-transition": "all 0ms",
							"-moz-transition": "all 0ms",
							"-ms-transition": "all 0ms",
							"transition": "all 0ms"
						});
						var lSNum = newOrder - 2;
						if(lSNum < 0){
							lSNum = slideNum - 3 - lSNum;
						}
						var lastSlide = '<li><img src="' + slidrArr[lSNum].imgURL + '" h="'+ slidrArr[lSNum].height +'"/></li>';
						slider.prepend(lastSlide);
						slider.children("li").eq(3).remove();
						/*if (1 < order && order < 2) {
							var lastSlide = '<li><img src="' + slidrArr[slideNum-1].imgURL + '" h="'+ slidrArr[slideNum-1].height +'"/></li>';
							slider.prepend(lastSlide);
							slider.children("li").eq(3).remove();
						} else if (order > 2 && order <= slideNum) {
							var previousSlide = '<li><img src="' + slidrArr[parseInt(order)-3].imgURL + '" h="'+ slidrArr[parseInt(order)-3].height +'"/></li>';
							slider.prepend(previousSlide);
							slider.children("li").eq(3).remove();
						} else {
							var lastSlide = '<li><img src="' + slidrArr[0].imgURL + '" h="'+ slidrArr[0].height +'"/></li>';
							slider.prepend(lastSlide);
							slider.children("li").eq(3).remove();
						}*/
						slider.children("li").css({"width": 100/4 + "%"});
					}, opts.duration);
				}
				if (opts.after && transEnd) opts.after();
				setTimeout(function() {
					sliding = false;
				}, 500);
			}

			function goToNext() {
				sliding = true;
				var order = slider.attr("data-order");
				var newOrder = parseInt(order)+1;
				if(newOrder > slideNum){
					newOrder = 1;
				}
				slider.attr("data-order", newOrder);
				var lSNum = newOrder;
				if(lSNum > slideNum-1){
					lSNum = newOrder-slideNum;
				}
				var lastSlide = '<li><img src="' + slidrArr[lSNum].imgURL + '" h="'+ slidrArr[lSNum].height +'"/></li>';
				slider.append(lastSlide);
				//slider.children("li").eq(3).remove();
				//if (order < slideNum) {
					/*if (order < slideNum-1) {
						var nextSlide = '<li><img src="' + slidrArr[parseInt(order)+1].imgURL + '" h="'+ slidrArr[parseInt(order)+1].height +'"/></li>';
						slider.append(nextSlide);
						slider.attr("data-order", parseInt(order)+1);
					} else if (order == slideNum-1) {
						slider.attr("data-order", slideNum);
						var firstSlide = '<li><img src="' + slidrArr[0].imgURL + '" h="'+ slidrArr[0].height +'"/></li>';
						slider.append(firstSlide);
						slider.attr("data-order", slideNum);
					}*/
					slider.children("li").css({"width": 100/4 + "%"});
					var position = -100/4*2;
					slider.css({
						"-webkit-transform": "translate3d(" + position + "%, 0, 0)",
						"-moz-transform": "translate3d(" + position + "%, 0, 0)",
						"-ms-transform": "translate3d(" + position + "%, 0, 0)",
						"transform": "translate3d(" + position + "%, 0, 0)",
						"-webkit-transition": "all " + opts.duration + "ms " + opts.easing + "",
						"-moz-transition": "all " + opts.duration + "ms " + opts.easing + "",
						"-ms-transition": "all " + opts.duration + "ms " + opts.easing + "",
						"transition": "all " + opts.duration + "ms " + opts.easing + ""
					});
					count();
					if (transEnd) {
						setTimeout(function() {
							var position = -100/4;
							slider.css({
								"-webkit-transform": "translate3d(" + position + "%, 0, 0)",
								"-moz-transform": "translate3d(" + position + "%, 0, 0)",
								"-ms-transform": "translate3d(" + position + "%, 0, 0)",
								"transform": "translate3d(" + position + "%, 0, 0)",
								"-webkit-transition": "all 0ms",
								"-moz-transition": "all 0ms",
								"-ms-transition": "all 0ms",
								"transition": "all 0ms"
							});
							slider.children("li").eq(0).remove();
						}, opts.duration);
					}
					setTimeout(function() {
						sliding = false;
					}, 500);
				//}
			}

			// Click event settings
			if (opts.click) {
				// slider.click(function(e) {
					// if ((!sliding) || (slider.attr("data-order") == slideNum)) {
					// 	var offset = sliderWrapper.offset();
					// 	if ((e.clientX - offset.left < sliderWidth / 2) && (slider.attr("data-order") > 1)) {
					// 		goToPrevious();
					// 	} else if (slider.attr("data-order") < slideNum - 1) {
					// 		goToNext();
					// 	}
					// }
				// });
			}

			// Autostart
			if (opts.autostart) {
				var autoAnimation = setInterval(function() {
					goToNext();
				}, opts.delay);
			}

            // Keypress event settings
			$(document).on('keydown', keyPressEvent);

			function keyPressEvent(e) {
				if ((opts.keyboard && !sliding) || (slider.attr("data-order") == slideNum)) {
					if (e.keyCode == 37) {
						goToPrevious();
					} else if (e.keyCode == 39) {
						goToNext();
					}
				}
			};

			// Counter settings
			function count() {
				cover();
				if (opts.counter) {
					var order = slider.attr("data-order");
					var color = slidrArr[order-1].color;
					var title = slidrArr[order-1].title;
					var desc = slidrArr[order-1].desc;
					$("h3.projectTitle").empty().append(title);
					$("p.projectDesc").empty().append(desc);
					$("h3.projectTitle").css("color", color); $("p.projectDesc").css("color", color);
					// Need to be hugged!
					if (order < project1.length + 1) {
						var lastProject = ".slidr-counter-" + projectNum;
						$(".slidr-counter-container").children("div").removeClass("slidr-counter-unselected");
						$(lastProject).addClass("slidr-counter-unselected");
						$(".slidr-counter-2").addClass("slidr-counter-unselected");
						$("span.slidr-counter-current-1").empty();
						$("span.slidr-counter-current-1").text("0"+(order));
						slidePos = 0;
					} else if (order < project1.length + project2.length + 1) {
						$(".slidr-counter-container").children("div").removeClass("slidr-counter-unselected");
						$(".slidr-counter-1").addClass("slidr-counter-unselected");
						$(".slidr-counter-3").addClass("slidr-counter-unselected");
						$("span.slidr-counter-current-2").empty();
						$("span.slidr-counter-current-2").append("0"+(order - project1.length));
						slidePos = -(sliderWidth / 3);
					} else if (order < project1.length + project2.length + project3.length + 1) {
						$(".slidr-counter-container").children("div").removeClass("slidr-counter-unselected");
						$(".slidr-counter-2").addClass("slidr-counter-unselected");
						$(".slidr-counter-4").addClass("slidr-counter-unselected");
						$("span.slidr-counter-current-3").empty();
						$("span.slidr-counter-current-3").append("0"+(order - project1.length - project2.length));
						slidePos = -(sliderWidth / 3) - (sliderWidth / 3);
					} else if (order < project1.length + project2.length + project3.length + project4.length + 1) {
						$(".slidr-counter-container").children("div").removeClass("slidr-counter-unselected");
						$(".slidr-counter-3").addClass("slidr-counter-unselected");
						$(".slidr-counter-5").addClass("slidr-counter-unselected");
						$("span.slidr-counter-current-4").empty();
						$("span.slidr-counter-current-4").append("0"+(order - project1.length - project2.length - project3.length));
						slidePos = -(sliderWidth / 3) - (sliderWidth / 3) * 2;
					} else if (order < project1.length + project2.length + project3.length + project4.length + project5.length+ 1) {
						$(".slidr-counter-container").children("div").removeClass("slidr-counter-unselected");
						$(".slidr-counter-4").addClass("slidr-counter-unselected");
						$(".slidr-counter-6").addClass("slidr-counter-unselected");
						$("span.slidr-counter-current-5").empty();
						$("span.slidr-counter-current-5").append("0"+(order - project1.length - project2.length - project3.length - project4.length));
						slidePos = -(sliderWidth / 3) - (sliderWidth / 3) * 3;
					} else if (order < project1.length + project2.length + project3.length + project4.length + project5.length + project6.length + 1) {
						$(".slidr-counter-container").children("div").removeClass("slidr-counter-unselected");
						$(".slidr-counter-5").addClass("slidr-counter-unselected");
						$(".slidr-counter-7").addClass("slidr-counter-unselected");
						$("span.slidr-counter-current-6").empty();
						$("span.slidr-counter-current-6").append("0"+(order - project1.length - project2.length - project3.length - project4.length - project5.length));
						slidePos = -(sliderWidth / 3) - (sliderWidth / 3) * 4;
					} else if (order < project1.length + project2.length + project3.length + project4.length + project5.length + project6.length + project7.length + 1) {
						$(".slidr-counter-container").children("div").removeClass("slidr-counter-unselected");
						$(".slidr-counter-6").addClass("slidr-counter-unselected");
						$(".slidr-counter-1").addClass("slidr-counter-unselected");
						$("span.slidr-counter-current-7").empty();
						$("span.slidr-counter-current-7").append("0"+(order - project1.length - project2.length - project3.length - project4.length - project5.length - project6.length));
						slidePos = -(sliderWidth / 3) - (sliderWidth / 3) * 5;
					} else if (order < project1.length + project2.length + project3.length + project4.length + project5.length + project6.length + project7.length + 1) {
						$(".slidr-counter-container").children("div").removeClass("slidr-counter-unselected");
						$(".slidr-counter-6").addClass("slidr-counter-unselected");
						$(".slidr-counter-1").addClass("slidr-counter-unselected");
						$("span.slidr-counter-current-7").empty();
						$("span.slidr-counter-current-7").append("0"+(order - project1.length - project2.length - project3.length - project4.length - project5.length - project6.length));
						slidePos = -(sliderWidth / 3) - (sliderWidth / 3) * 5;
					}


					$(".slidr-counter-container").css({
						"width": projectNum * sliderWidth,
						"-webkit-transform": "translate3d(" + slidePos  + "px, 0, 0)",
						"-moz-transform": "translate3d(" + slidePos + "px, 0, 0)",
						"-ms-transform": "translate3d(" + slidePos + "px, 0, 0)",
						"transform": "translate3d(" + slidePos + "px, 0, 0)",
						"-webkit-transition": "all 500ms",
						"-moz-transition": "all 500ms",
						"-ms-transition": "all 500ms",
						"transition": "all 500ms"
					});
				}
			};
			if ((slideNum > 1) && (opts.counter)) {
				var order = slider.attr("data-order");
				var	slidePos = -(sliderWidth / 3);
				slider.after("<div class='slidr-counter-container'></div>");
				var lastLastProject = "project" + (projectNum - 1);
				var lastProject = "project" + projectNum;
				$("div.slidr-counter-container").append("<div class='slidr-counter-0'>&nbsp;</div>");
				for (var i=1; i<projectNum+1; i++) {
					var counterTotal = "project" + i;
					$("div.slidr-counter-container").append("<div class='slidr-counter-"+i+"'><p><span class='slidr-counter-current-"+i+"'>01</span><span class='slidr-counter-slash'>/</span><span class='slidr-counter-total-"+i+"'>0" + eval(counterTotal).length + "</span></p></div>");
				};
				$(".slidr-counter-container").children("div").css({ width: sliderWidth / 3 });
				count();
			}

			// Start() callback
			if (opts.start) opts.start();

			function resizing() {
				sliderWidth = $(window).width();
				slider.css({"width": sliderWidth*4 + "px"});
				$(".slidr-counter-container").children("div").css({"width": viewportWidth / 3});

			}
			$(window).on('resize', resizing);

			// Touch events settings
			if (opts.touch && !sliding) {
				slider.swipe({
					swipeStatus: swipeStatus,
					allowPageScroll: "none",
					tap: function(){
						if(opts.$scope){
							slider.swipe('destroy');
							$(document).off('keydown', keyPressEvent);
							$(window).off('resize', resizing);
							var c = slider.attr('data-order');
							opts.$scope.refresh(c);
						}
					}
				});
				var swipeSlidingSpeed = 500;
			}

			function swipeStatus(event, phase, direction, distance) {
				if ((!sliding) || (slider.attr("data-order") == slideNum)) {
					if (phase == "move" && (direction == "left" || direction == "right")) {
						var duration=0;
						if ((direction == "left")/* && (slider.attr("data-order") < slideNum) */) {
							swipeScrollSlide(sliderWidth + distance, duration);
						} else if ((direction == "right")/* && (slider.attr("data-order") > 1)*/) {
							swipeScrollSlide(sliderWidth - distance, duration);
							}
					} else if (phase == "cancel") {
						swipeScrollSlide(sliderWidth, swipeSlidingSpeed);
					} else if (phase == "end") {
						if (direction == "right") {
							goToPrevious();
						} else if (direction == "left") {
							goToNext();
						}
						count();
						dynamicHeights();
					}
				}
			}
			
			function swipeScrollSlide(distance, duration) {
				slider.css({
					"-webkit-transition-duration": duration / 2 + "ms",
					"transition-duration": duration / 2 + "ms"
				});
				var value = (distance < 0 ? "" : "-") + Math.abs(distance).toString();
				slider.css({
					"-webkit-transform": "translate3d("+ value +"px, 0px, 0px)",
					"-o-transform": "translate3d(("+ value +"px, 0px, 0px)",
					"-ms-transform": "translate3d(("+ value +"px, 0px, 0px)",
					"transform": "translate3d(("+ value +"px, 0px, 0px)"
					});
				currentSectionOrder = -(value / viewportHeight);
			}
		});
	};

}(jQuery));