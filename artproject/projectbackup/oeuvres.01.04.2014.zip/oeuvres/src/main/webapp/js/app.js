var isDev 		= false, siteUser = null;
siteUser 		= $.session.get('oeuAppUser');
hasLocalStorage = localStorageTest();

if (siteUser===undefined || siteUser==null || siteUser==""){
	var hasUser = false;
	if(hasLocalStorage && localStorage.getItem('user') !== null){
		var savedUser = JSON.parse(localStorage.getItem('user'));
		var d = new Date();
		var timeNow = Math.floor(d.getTime()/1000/60);
		var timeSince = timeNow - savedUser.time;
		if(timeSince < 15){
			siteUser = JSON.stringify(savedUser.user);
			hasUser = true;
		} else {
			localStorage.removeItem('user');
			localStorage.removeItem('data');
		}
	}
	if(!hasUser){
		localStorage.removeItem('data');
		location.href = "login.html";
	}
}

siteUser 		= JSON.parse(siteUser);
var oeuApp 		= angular.module('oeuApp', ['ngResource','ngSanitize','services','ngCookies']);
var dataGB = [], categorysGB = [], artworksGB = [], artistsGB = [], slideshowsGB = [], tagsGB = [], locationsGB = [];
oeuApp.config(function($routeProvider){
	$routeProvider.
		when('/', {
			controller:'homeController',templateUrl:'views/home.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/browse/:by/:id', {
			controller:'browseController',templateUrl:'views/browse.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/browse/:by/', {
			controller:'browseController',templateUrl:'views/browse.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/object/:artworkId', {
			controller: 'objectController', templateUrl: 'views/object.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/artist/:artistId', {
			controller: 'artistController', templateUrl: 'views/artist.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/artwork/:artworkId', {
			controller: 'artworkController', templateUrl: 'views/artwork.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/artworks/', {
			controller: 'categoryController', templateUrl: 'views/category.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/sculptures/', {
			controller: 'categoryController', templateUrl: 'views/category.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/antiques/', {
			controller: 'categoryController', templateUrl: 'views/category.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/category/:categoryId', {
			controller: 'categoryController', templateUrl: 'views/category.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/tag/:tagId', {
			controller: 'tagController', templateUrl: 'views/tag.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/year/:yearId', {
			controller: 'yearController', templateUrl: 'views/year.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/origin/:originId', {
			controller: 'originController', templateUrl: 'views/category.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/slideshow/:slideshowId', {
			controller: 'slideshowController', templateUrl: 'views/slideshow.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/artists/', {
			controller: 'allArtistController', templateUrl: 'views/allartist.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/categories/', {
			controller: 'allCategoryController', templateUrl: 'views/allcategory.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/all/', {
			controller: 'allCategoryController', templateUrl: 'views/all.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		when('/location/:artworkId', {
			controller: 'locationController', templateUrl: 'views/location.html',resolve:{data:function(dataService){return dataService.promise}}
		}).
		otherwise({redirectTo: '/'});
}).run(['$rootScope', '$location', function ($rootScope, $location) {
	//need to check sessionToken
	$rootScope.$on("$routeChangeStart", function (event, next, current) {
		$('#backBtn').css('display','none');
		$('#galleryCounter').css('display','none');
		$('#artworkloading').hide();
		$rootScope.$broadcast('saveState');
	});

	$rootScope.$on('saveState', function(){
		var d = new Date();
		var data = {
			user: siteUser,
			time : Math.floor(d.getTime()/1000/60)
		}
		data = JSON.stringify(data);
		localStorage.setItem('user', data);
	});
	if(hasLocalStorage){
		window.onbeforeunload = function (event) {
		    $rootScope.$broadcast('saveState');
		};
	}
}]);
angular.element(document).ready(function () {});