var oe = oe || {};

oe.Menu = {}; 

oe.Menu.init = function() { 

	this.throttledHandler = $.throttle(250, $.proxy(this._scrollHandler, this));
	this._el = $('.drawerBtn, #search');

	var self = this;

	$(document).bind('scroll', this.throttledHandler);
	
};

oe.Menu._el = null;

oe.Menu._lastScroll = 0;

oe.Menu._hideShowOffset = 20;

oe.Menu._visible = true;

oe.Menu._open = false;

oe.Menu._scrollHandler = function() {
	var scrollTop = $(window).scrollTop(),
		direction = (scrollTop > this._lastScroll) ? 'down' : 'up',
		difference = Math.abs(scrollTop - this._lastScroll);	

	if (scrollTop > -1) {
		if (direction === 'down' && difference >= this._hideShowOffset) {
			this.hide();
		}
		else if (direction === 'up' && difference >= this._hideShowOffset) {
			this.show();
		}
	}
	else {
		this.show();
	}

	this._lastScroll = scrollTop;
};

oe.Menu.hide = function() {
	if (this._visible && !$('body').hasClass('searchOpen')) {
		this._el.addClass('hidden');
		this._visible = false;
	}
};

oe.Menu.show = function() {
	if (! this._visible) {
		this._el.removeClass('hidden');
		this._visible = true;
	}
};