'use strict';

oeuApp.controller('locationController', function($scope, $route,$location,$cookieStore, artworks, categories,dataDelegate){
	artworks.init();categories.init();dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
	pageContentObj.removeClass('galleryView');$('#removeFromSlideshow').css('display','none');

	var artid = $route.current.params.artworkId;
	var artObj= null;
	if (artid !== undefined && artid!="" && artid>0){
		artObj = _.find(artworks.items, function(obj, key){ return obj.id == artid;});
	}
	if (artObj===undefined || artObj==null){
		$location.path('/');
	}else{
		$scope.categoryTitle = artObj.house + ' ' + artObj.town + '('+artObj.country+')';
		$scope.artworks = _.filter(artworks.items, function(obj, key){ return obj.house==artObj.house && obj.town==artObj.town && obj.country==artObj.country; });

	}
	$scope.setLoading = function(){
		var $container = $('#artistArtworks .grid ul');
		$container.imagesLoaded(function(){
			gridViewSet();
		});
	};
	$scope.gotoPage = function(obj){
		if (obj !== undefined && obj !==null && obj.id>0 && !$('#contextMenu').hasClass('isVisible')){
			var vlist = _.pluck($scope.artworks, 'id');
			$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+obj.id);
		}
	};
});


oeuApp.directive('categoryallRenderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
           if ($scope.$last === true) {
                element.ready(function () {
                    $scope.setLoading();
                });
           }
		}
	};
});