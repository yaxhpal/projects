'use strict';

oeuApp.directive('featureArtistsList', function(){
	return {
		restrict: 'E',
		templateUrl: 'views/featureArtistsList.html',
		scope: {},
		controller: function($scope, artists){
			artists.init();
			if (artists.items.length>8){
				var newList 	= artists.items.slice(0);
				$scope.artists   = _.flatten(newList.toRandom(8));
				newList = null;
			}else{
				$scope.artists = artists.items;
			}
			$scope.set_width = function(){
				$('#featuredArtistscarousel ul').css('width', function() {
					var itemNo = $(this).children('li').length;
					return itemNo*240+140;
				});
			};
		},
		link: function($scope,element, attr){
		}
	}
} );

oeuApp.directive('artistsRenderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
           if ($scope.$last === true) {
                element.ready(function () {
                    $scope.set_width();
                });
           }
		}
	};
});