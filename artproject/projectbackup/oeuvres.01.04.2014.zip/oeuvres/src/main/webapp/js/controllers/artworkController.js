'use strict';

oeuApp.controller('artworkController', function($rootScope,$scope, $route, $location,$cookies,$cookieStore,$compile, artworks,dataDelegate,categories,tags, slideshows){
	artworks.init();categories.init();tags.init();dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
	pageContentObj.removeClass('galleryView').addClass('infoView');
	$('#backBtn').css('display','block');$('#galleryCounter').css('display','block');
	var pageHistory = $cookieStore.get('pageFromHistory');
	var detachslideshow = -1;
	var detachObj = null;
	if (pageHistory!==undefined && pageHistory!= null && pageHistory!="" && pageHistory!="empty"){
		$('#removeFromSlideshow').css('display','block');
		$cookieStore.put('pageFromHistory',"");
		var tmpObj = JSON.parse(pageHistory);
		detachslideshow = tmpObj.slideshow;
		detachObj = _.find(slideshows.items, function(obj, key){ return obj.id == detachslideshow;});
	}else{
		$('#removeFromSlideshow').css('display','none');
	}

	var aid = $route.current.params.artworkId;
	var artobj = null;
	if (aid!==undefined && aid!=null && aid>0){
		artobj = _.find(artworks.items, function(obj, key){return obj.id==aid;});
	}
	if (artobj==null){
		$location.path('/');
	}
	var pagearts = [];
	$scope.artworks = [];
	var artworks8only = $cookieStore.get('artworks8only');
	if (artworks8only!==undefined && artworks8only!=null && artworks8only!=""){
		var vlist = artworks8only.split(',');
		for (var i=0;i<vlist.length;i++){
			var vobj = _.find(artworks.items, function(obj, key){return obj.id==vlist[i];});
			pagearts.push(vobj);
		}
		$cookieStore.put('artworks8only',"");
	}else{
		pagearts.push(artobj);
	}
	var exhibitions = dataDelegate.get('exhibitions');
	for (var i=0;i<pagearts.length;i++){
		var categoryList = _.filter(categories.items, function(obj, key){ return _.contains(pagearts[i].categories, obj.id);});
		pagearts[i].categoryList = categoryList;
		var tagList = _.filter(tags.items, function(obj, key){ return _.contains(obj.artworks, pagearts[i].id);});
		pagearts[i].tagList = tagList;
		var artslist = _.filter(artworks.items, function(obj, key){
			return obj.artist == artobj.artist && obj.id != artobj.id;
		});
		pagearts[i].artList = artslist;
		var exbiList = _.filter(exhibitions, function(obj, key){ return _.contains(pagearts[i].exhibitions, obj.id); });
		pagearts[i].exhibitionsList = exbiList;
	}
	globalAWS = pagearts;
	var listToPage = [], startPoint = -1;
	startPoint = _.indexOf(_.pluck(pagearts, 'id'), aid*1);
	if (pagearts.length>5){
		globalPointer = startPoint;
		listToPage = getList(globalPointer);
		startPoint = 2;
	}else{
		listToPage = pagearts;
	}
	showPointer = startPoint + 1;
	$scope.artworks = listToPage;
	$scope.setSlide 	= function(){
		artwork_slideshow_init(startPoint, 'gallery', $scope);
		infoImageSize();attachArtworkEvents($scope);
	};
	$scope.removeTag = function(artwordid, tagid, loopByAngular){
		dataDelegate.detachTag(artwordid, tagid, function(d){
			$rootScope.$apply(function(){
				if (!loopByAngular){
					$('#artTag'+artwordid+'-'+tagid).remove();
				}
				var tagIndex = -1;
				for (var i=0;i<tags.items.length;i++){
					if (tags.items[i].id==d.id){
						tagIndex = i;
						tags.items[i].artworks = d.artworks;
						break;
					}
				}
				if (tagIndex<0){
					tags.items.push(d);
				}
/*
				if (d.length>0){
					for (var i=0;i<tags.items.length;i++){
						if (tags.items[i].id==tagid){
							tags.items[i].artworks = d.artworks;
							break;
						}
					}
				}else{
					var tagIndex = -1;
					for (var i=0;i<tags.items.length;i++){
						if (tags.items[i].id==tagid){
							tagIndex = i;break;
						}
					}
					tags.items.splice(tagIndex,1);
				}
				*/
				$scope.updateTagsGlobal();
			});
		});
	};
	$scope.addTag = function(artid, newTag, that, waction, currentTags, loopByAngular){
		dataDelegate.attachTag(artid, newTag, function(d){
			$rootScope.$apply(function(){
				var list1Updated = false;
				_.each(tags.items, function(obj, key){
					if (obj.id==d.id){
						obj.artworks = d.artworks;
						list1Updated = true;
					}
				});				
				if (!list1Updated){ tags.items.push(d); }
				if (waction=="add" || waction=="attach"){
					$scope.updateTagsGlobal();
					if (!loopByAngular){
						var newTagStr = newTag;
						if (currentTags>0){
							newTagStr = ', ' + newTagStr;
						}
						if (waction=="add" || waction=="attach"){
							$('<li id="artTag'+artid+'-'+d.id+'"><a class="tagName" href="" artwordid="'+artid+'" data-ref="'+d.id+'">'+newTagStr+'</a></li>').insertBefore($(that).parent('li'));
						}
					}
				}
			});
		});
	};
	$scope.addComment = function(artid, comment, that, submitByAngular){
		comment = comment.replace(/\r\n|\r|\n/g,"<br />");
		dataDelegate.addComment(artid, comment, function(d){
			$rootScope.$apply(function(){
				for (var i=0;i<artworks.items.length;i++){
					if (artworks.items[i].id==artid){
						artworks.items[i].comments.push({
							id:d.id, message: d.message, date: d.date, authorId:d.authorId, author:d.author
						});
						if (!submitByAngular){
							$(that).parent().parent().find('.artworkCommentsTotal').html('('+artworks.items[i].comments.length+')');
							$(that).parent().find('ul').append('<li><p>'+d.message+'</p><p class="author">'+d.author+' <span class="timestamp">'+new Date(d.date).format('h:MM, d mmmm yyyy')+'</span></p></li>');
						}
						break;
					}
				}
			});
		});		
	};
	$scope.removeArtworkFromSlideshow = function(artid){
		dataDelegate.detachArtwork(artid, detachslideshow, function(d){
			$rootScope.$apply(function(){
				for (var i=0;i<slideshowsGB.length;i++){
					if (slideshowsGB[i].id==detachslideshow){
						slideshowsGB[i].artworks = d.artworks;
						break;
					}
				}
			});
		});
		var slideshowTitle = detachObj.name;
		setTimeout(function() {$('#drawerRight .menu li a').removeClass('selected');}, 100);
		setTimeout(closeDrawers, 250);
		showAlert('removeedToSlideshow', slideshowTitle);
	};
	$scope.gotoPage 			= function(id){
		if (id>0 && !$('#contextMenu').hasClass('isVisible')){
			//var vlist = _.pluck($scope.artworks, 'id');
			//$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+id);
		}
		
	};
	$scope.updateTagsGlobal = function(){
		for (var i=0;i<globalAWS.length;i++){
			var tagList = _.filter(tags.items, function(obj, key){ return _.contains(obj.artworks, globalAWS[i].id);});
			globalAWS[i].tagList = tagList;
		}
	};
	$scope.hasImportExport = function(obj){
		var showme = false;
		if ((obj.importRestriction=="" || obj.importRestriction==null) && (obj.exportRestriction=="" || obj.exportRestriction==null)){
			showme = true;
		}
		return showme;
	};
	$scope.conditionText = function(obj){
		var txt = '';
		if (obj.conditionCode!="" && obj.conditionCode!=null && obj.conditionDescription!="" && obj.conditionDescription!=null){
			txt = obj.conditionCode + ', ' + obj.conditionDescription;
		}else{
			if (obj.conditionCode!="" && obj.conditionCode!=null){
				txt = obj.conditionCode;
			}else if (obj.conditionDescription!="" && obj.conditionDescription!=null){
				txt = obj.conditionDescription;
			}
		}
		return txt;
	};
	$scope.stringToLower = function(string){
		var lS = string.toLowerCase();
		return lS;
	};
});

oeuApp.directive('artworklistRenderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
           if ($scope.$last === true) {
                element.ready(function () {
                    $scope.setSlide();
                });
           }
		}
	};
});