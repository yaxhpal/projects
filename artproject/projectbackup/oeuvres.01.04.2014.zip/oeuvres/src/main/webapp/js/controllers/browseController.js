'use strict';

oeuApp.controller('browseController', function($rootScope, $scope, $route, $location, $cookieStore, artworks, tags, locations, slideshows, dataDelegate, opts){
	$('#loading').removeClass('isHidden');
	$('#pageContent').addClass('noTransGrid');
	$scope.filterType = $route.current.params.by;
	$scope.filterID = $route.current.params.id;

	artworks.init();
	dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	pageContentObj.removeClass('galleryView');
	$('#removeFromSlideshow').css('display','none');

	var filteredArtworks, filteredTitle, filteredCallback;
	
	switch($scope.filterType){
		case 'category':
			switch(parseInt($scope.filterID)){
				case 0:
					filteredTitle = 'Artworks';
					break;
				case 1:
					filteredTitle = 'Sculptures';
					break;
				case 2:
					filteredTitle = 'Antiques';
					break;
			}
			filteredArtworks = _.filter(artworks.items, function(obj,key) { return obj.category == $scope.filterID; });
			break;

		/*case 'category':
			var category = _.find(categories.items, function(obj, key){ return obj.id == $scope.filterID; });
			filteredTitle = category.name;
			filteredArtworks = _.filter(artworks.items, function(obj, key){ return _.contains(obj.categories, parseInt($scope.filterID));});
			break;*/

		case 'slideshow':

			var slideshow 	= _.find(slideshows.items, function(obj, key){ return obj.id == $scope.filterID;});
			filteredArtworks = _.filter(artworks.items, function(obj,key){ return _.contains(slideshow.artworks, obj.id); });
			filteredTitle = slideshow.name;
			$scope.isSlideshow = true;
			$('body').addClass('isSlideshow');
			$scope.$on('$destroy', function(){
				$('body').removeClass('isSlideshow');
			});
			break;

		case 'location':

			var stringArr = $scope.filterID.split('&country=');

			var location = {
				location: stringArr[0],
				country: (stringArr[1]) ? stringArr[1] : ''
			}
			filteredTitle = location.location;
			if(location.country){
				filteredTitle += ', '+location.country;
			}

			var locations = _.where(locations.items, {location: location.location, country: location.country});
			var aws = [];
			_.each(locations, function(_i){
				var artObj = _.findWhere(artworks.items, {locationId: _i.id});
				if(artObj){
					aws.push(artObj);
				}
			});

			filteredArtworks = aws;

			break;

		case 'tag':
			var tag = _.find(tags.items, function(obj, key){ return obj.id == $scope.filterID; });
			filteredTitle = tag.name;
			filteredArtworks = [];
			_.each(tag.artworks, function(_i){
				filteredArtworks.push(_.find(artworks.items, function(obj){ return obj.id == _i; }));
			});
			break;		
		
		case 'year':
			filteredCallback = function(){
				scrollToElement($scope.$el.find('li[year-ref="'+$scope.filterID+'"]:eq(0)'), 'middle');
			}
			filteredArtworks = artworks.items;
			break;

		default:
			filteredArtworks = artworks.items;
			break;
	}

	filteredArtworks = _.sortBy(filteredArtworks, function(obj){
		return obj.year;
	});

	$scope.title = filteredTitle;
	$scope.artworks = filteredArtworks;
	opts.updateOption('artworksArr', $scope.artworks);

	if($scope.artworks.length == 0){ $scope.noArtworks = true; }
	if(filteredCallback){
		$scope.callback = filteredCallback;
	}

	if($scope.isSlideshow){
		opts.updateOption('fromSlideshow', true);
	} else {
		opts.updateOption('fromSlideshow', false);
	}

	$rootScope.$on('reloadData', function(){
	});
});


oeuApp.directive('renderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
			if ($scope.$last === true) {
				element.ready(function () {
                	$scope.hasLoaded();
                });
           }
		}
	};
});