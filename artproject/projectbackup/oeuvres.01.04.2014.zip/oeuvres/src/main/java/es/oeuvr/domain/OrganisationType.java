package es.oeuvr.domain;

public enum OrganisationType
{
	ADMIN, GALLARY, PERSONAL, OTHER
}