package es.oeuvr.api;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LogoutRequest extends ArtApplicationRequest {

	public String username;
    
    public LogoutRequest(){}
}
