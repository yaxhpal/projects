package es.oeuvr.service;

import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.List;

import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.ws.rs.Consumes;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.Provider;

import org.jboss.logging.Logger;
import org.jboss.resteasy.annotations.interception.ServerInterceptor;
import org.jboss.resteasy.core.Headers;
import org.jboss.resteasy.core.ResourceMethod;
import org.jboss.resteasy.core.ServerResponse;
import org.jboss.resteasy.spi.Failure;
import org.jboss.resteasy.spi.HttpRequest;
import org.jboss.resteasy.spi.interception.PreProcessInterceptor;

import com.nimbusds.jose.JOSEException;

@Provider
@ServerInterceptor
@Consumes({ MediaType.APPLICATION_JSON })
public class SecurityInterceptor implements PreProcessInterceptor {

	private static final Logger log = Logger.getLogger(SecurityInterceptor.class);
	private static final ServerResponse ACCESS_FORBIDDEN = new ServerResponse("Nobody can access this resource", 403, new Headers<Object>());
	private static final ServerResponse ACCESS_DENIED = new ServerResponse("Unauthorized", 401, new Headers<Object>());

	@Override
	public ServerResponse preProcess(HttpRequest httpRequest, ResourceMethod resourceMethod) throws Failure, WebApplicationException {
		log.info("This is my intercepter");
		log.info("Requested Method is " + resourceMethod.getMethod().getName());
		Method method = resourceMethod.getMethod();
		final HttpHeaders headers = httpRequest.getHttpHeaders();
		final List<String> authorization = headers.getRequestHeader("sessionToken");
		if (method.getName() == "login" ) {
			//If no authorization information present; block access
			if(authorization == null || authorization.isEmpty()) {
				return ACCESS_DENIED;
			} else {
				String sessionToken = authorization.get(0);
				
				try {
					int status = TokenService.verify(sessionToken);
					if (status == TokenService.VALID) {
						return null;
					}
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (JOSEException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				if (!sessionToken.equals("This is test Token")) {
					return ACCESS_DENIED;
				}
			}
		}
		// Access allowed for all
		if (method.isAnnotationPresent(PermitAll.class)) {
			return null;
		}
		// Access denied for all
		if (method.isAnnotationPresent(DenyAll.class)) {
			return ACCESS_FORBIDDEN;
		}
		// Return null to continue request processing
		return null;
	}
}