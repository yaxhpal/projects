package es.oeuvr.domain;

public enum Category
{
	ARTWORK, SCULPTURE, ANTIQUE
}