package es.oeuvr.api;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AddArtworkToSlideshowRequest extends ArtApplicationRequest {
	public Long artworkId;
	public Long slideshowId;
}
