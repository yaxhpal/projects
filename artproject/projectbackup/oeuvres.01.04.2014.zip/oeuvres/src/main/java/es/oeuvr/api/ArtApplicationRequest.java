package es.oeuvr.api;

public class ArtApplicationRequest {
	    
	public String sessionToken;
	
	public ArtApplicationRequest() {
		// TODO Auto-generated constructor stub
	}
}
