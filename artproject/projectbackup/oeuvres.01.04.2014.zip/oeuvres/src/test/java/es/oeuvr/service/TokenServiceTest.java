package es.oeuvr.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Test;

public class TokenServiceTest {

//	@Test
//	public void testCreatToken() {
//		try {
//			String testToken = TokenService.creatToken("yashpal@techletsolutions.com");
//			assertEquals(TokenService.verify(testToken), TokenService.VALID);
//		} catch (Exception e) {
//			fail(e.getMessage());
//		} 
//	}
//
//	@Test
//	public void testVerify() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testMain() {
//		fail("Not yet implemented");
//	}

}
