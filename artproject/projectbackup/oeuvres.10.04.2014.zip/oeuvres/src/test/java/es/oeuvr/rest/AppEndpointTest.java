package es.oeuvr.rest;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppEndpointTest {

//	@Test
//	public void testLogin() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testLogout() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testRelocate() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testSaveComment() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testAddArtworkToTag() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testRemoveArtworkFromTag() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testSaveSlideshow() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testDeleteSlideshowById() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testAddArtworkToSlideshow() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testRemoveArtworkFromSlideshow() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testListAll() {
//		fail("Not yet implemented");
//	}

}
