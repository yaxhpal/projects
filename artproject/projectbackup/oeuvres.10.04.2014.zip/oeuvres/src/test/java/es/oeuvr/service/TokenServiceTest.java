package es.oeuvr.service;

import static org.junit.Assert.fail;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.Test;
import org.junit.runner.RunWith;

//@RunWith(Arquillian.class)
public class TokenServiceTest {

//    @Deployment
//    public static JavaArchive createDeployment() {
//        return ShrinkWrap.create(JavaArchive.class)
//            .addClass(TokenService.class)
//            .addAsManifestResource(EmptyAsset.INSTANCE, "beans.xml");
//    }
//
//	@Test
//	public void testCreatToken() {
//		try {
//			String testToken = TokenService.creatToken("yashpal@techletsolutions.com");
//			System.out.println(testToken);
//		} catch (Exception e) {
//			fail(e.getMessage());
//		} 
//	}
//	
//	@Test
//	public void testVerify() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testMain() {
//		fail("Not yet implemented");
//	}
}