package es.oeuvr.rest.exception;

public class Message {

	
}
