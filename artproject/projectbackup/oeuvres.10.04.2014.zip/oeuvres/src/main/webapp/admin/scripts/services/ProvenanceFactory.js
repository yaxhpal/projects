angular.module('oeuvres').factory('ProvenanceResource', function($resource){
    var resource = $resource('../rest/provenances/:ProvenanceId',{ProvenanceId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});