angular.module('oeuvres').controller('EditUploadController', function ($scope, $location, locationParser, ArtworkResource , CategoryResource, UserResource, ArtistResource) {
  alert("EditUploadController");
});