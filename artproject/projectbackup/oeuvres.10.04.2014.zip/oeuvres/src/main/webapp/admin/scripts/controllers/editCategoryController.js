

angular.module('oeuvres').controller('EditCategoryController', function($scope, $routeParams, $location, CategoryResource ) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.category = new CategoryResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Categorys");
        };
        CategoryResource.get({CategoryId:$routeParams.CategoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.category);
    };
    $scope.typeList = CategoryResource.queryAll(function(items){
       	$scope.typeList = $.map(items, function(item) {
                return ( {
                    value : item,
                    id :item.id,
                    text : item.name
                   });
            });
       });
    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
            $location.path("/Categorys");
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.category.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Categorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Categorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.category.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});