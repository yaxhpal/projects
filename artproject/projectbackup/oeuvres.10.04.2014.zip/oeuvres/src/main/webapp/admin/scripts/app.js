'use strict';

angular.module('oeuvres',['ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/Artists',{templateUrl:'views/Artist/search.html',controller:'SearchArtistController'})
      .when('/Artists/new',{templateUrl:'views/Artist/detail.html',controller:'NewArtistController'})
      .when('/Artists/edit/:ArtistId',{templateUrl:'views/Artist/detail.html',controller:'EditArtistController'})
      .when('/Artworks',{templateUrl:'views/Artwork/search.html',controller:'SearchArtworkController'})
      .when('/Artworks/new',{templateUrl:'views/Artwork/detail.html',controller:'NewArtworkController'})
      .when('/Artworks/edit/:ArtworkId',{templateUrl:'views/Artwork/detail.html',controller:'EditArtworkController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Comments',{templateUrl:'views/Comment/search.html',controller:'SearchCommentController'})
      .when('/Comments/new',{templateUrl:'views/Comment/detail.html',controller:'NewCommentController'})
      .when('/Comments/edit/:CommentId',{templateUrl:'views/Comment/detail.html',controller:'EditCommentController'})
      .when('/Documents',{templateUrl:'views/Document/search.html',controller:'SearchDocumentController'})
      .when('/Documents/new',{templateUrl:'views/Document/detail.html',controller:'NewDocumentController'})
      .when('/Documents/edit/:DocumentId',{templateUrl:'views/Document/detail.html',controller:'EditDocumentController'})
      .when('/Exhibitions',{templateUrl:'views/Exhibition/search.html',controller:'SearchExhibitionController'})
      .when('/Exhibitions/new',{templateUrl:'views/Exhibition/detail.html',controller:'NewExhibitionController'})
      .when('/Exhibitions/edit/:ExhibitionId',{templateUrl:'views/Exhibition/detail.html',controller:'EditExhibitionController'})
      .when('/Images',{templateUrl:'views/Image/search.html',controller:'SearchImageController'})
      .when('/Images/new',{templateUrl:'views/Image/detail.html',controller:'NewImageController'})
      .when('/Images/edit/:ImageId',{templateUrl:'views/Image/detail.html',controller:'EditImageController'})
      .when('/Locations',{templateUrl:'views/Location/search.html',controller:'SearchLocationController'})
      .when('/Locations/new',{templateUrl:'views/Location/detail.html',controller:'NewLocationController'})
      .when('/Locations/edit/:LocationId',{templateUrl:'views/Location/detail.html',controller:'EditLocationController'})
      .when('/Organisations',{templateUrl:'views/Organisation/search.html',controller:'SearchOrganisationController'})
      .when('/Organisations/new',{templateUrl:'views/Organisation/detail.html',controller:'NewOrganisationController'})
      .when('/Organisations/edit/:OrganisationId',{templateUrl:'views/Organisation/detail.html',controller:'EditOrganisationController'})
      .when('/Provenances',{templateUrl:'views/Provenance/search.html',controller:'SearchProvenanceController'})
      .when('/Provenances/new',{templateUrl:'views/Provenance/detail.html',controller:'NewProvenanceController'})
      .when('/Provenances/edit/:ProvenanceId',{templateUrl:'views/Provenance/detail.html',controller:'EditProvenanceController'})
      .when('/PurchaseHistorys',{templateUrl:'views/PurchaseHistory/search.html',controller:'SearchPurchaseHistoryController'})
      .when('/PurchaseHistorys/new',{templateUrl:'views/PurchaseHistory/detail.html',controller:'NewPurchaseHistoryController'})
      .when('/PurchaseHistorys/edit/:PurchaseHistoryId',{templateUrl:'views/PurchaseHistory/detail.html',controller:'EditPurchaseHistoryController'})
      .when('/Slideshows',{templateUrl:'views/Slideshow/search.html',controller:'SearchSlideshowController'})
      .when('/Slideshows/new',{templateUrl:'views/Slideshow/detail.html',controller:'NewSlideshowController'})
      .when('/Slideshows/edit/:SlideshowId',{templateUrl:'views/Slideshow/detail.html',controller:'EditSlideshowController'})
      .when('/Tags',{templateUrl:'views/Tag/search.html',controller:'SearchTagController'})
      .when('/Tags/new',{templateUrl:'views/Tag/detail.html',controller:'NewTagController'})
      .when('/Tags/edit/:TagId',{templateUrl:'views/Tag/detail.html',controller:'EditTagController'})
      .when('/Users',{templateUrl:'views/User/search.html',controller:'SearchUserController'})
      .when('/Users/new',{templateUrl:'views/User/detail.html',controller:'NewUserController'})
      .when('/Users/edit/:UserId',{templateUrl:'views/User/detail.html',controller:'EditUserController'})
      .when('/Upload',{templateUrl:'views/Upload/search.html',controller:'SearchUploadController'})
      .when('/Upload/new',{templateUrl:'views/Upload/detail.html',controller:'NewUploadController'})
      .when('/Upload/edit/:UploadId',{templateUrl:'views/Upload/detail.html',controller:'EditUploadController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
