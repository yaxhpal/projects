angular.module('oeuvres').controller('NewUploadController', function ($scope,$rootScope, $location,$http,UploadResource) {

	$scope.setFile = function (elem) {
		$scope.inputField = elem;
		$scope.file = elem.files[0];
	};

	$scope.artwork = $scope.artwork || {};

	$scope.uploadFile = function () {
		$scope.progressVisible=true;
		$scope.progress="Uploading...";
		var fd = new FormData(), xhr = new XMLHttpRequest();
		xhr.addEventListener("load", uploadComplete, false);
		fd.append("uploadedFile", $scope.file);
		xhr.open("POST", "../rest/uploadfile");
		xhr.send(fd);
		$scope.inputField.value = "";
	};

	function csvToArray(csvString){
		//[turn a csv string to js object jsfiddle]jsfiddle.net/barney/7vpAJ
		var csvArray=[];
		var csvrows=csvString.split(/\n/);
		var csvHeadears=csvrows.shift().split(';');
		for(var rowIndex=0;rowIndex<csvrows.length;rowIndex++){
			var rowArray=csvrows[rowIndex].split(';');
			var rowObject=csvArray[rowIndex]={};
			for(var propIndex=0;propIndex<rowArray.length;propIndex++){
				var propValue=rowArray[propIndex].replace('/^"|"$/g','');
				var propLabel=csvHeadears[propIndex].replace('/^"|"$/g','');
				rowObject[propLabel]=propValue;
			}
		}
		return 		csvArray;
	}
	
	function uploadComplete(evt) {
		/* This event is raised when the server send back a response */
		$scope.$apply(function(){
			var str=evt.target.responseText;
			$scope.progress=evt.target.responseText;
		});
		alert('saving');
		saveLog(evt);
		//readFile();
		
	}
	function saveLog(evt){
		
		var successCallback = function(data,responseHeaders){
			var id = locationParser(responseHeaders);
			//$location.path('/Categorys/edit/' + id);
			$location.path("/Categorys");
			$scope.displayError = false;
		};
		var errorCallback = function() {
			$scope.displayError = true;
		};
		uploadLog={};
		uploadLog.filename=$scope.file.name;
		uploadLog.comments="Not Yet Uploaded";
		UploadResource.save(uploadLog);//, successCallback, errorCallback


	}
	function readFile() {//LA MOD String Version. A tiny ajax library.  by, DanDavis
		var X = !window.XMLHttpRequest ? new ActiveXObject('Microsoft.XMLHTTP') : new XMLHttpRequest();
		X.open('GET','../rest/uploadfile?fname='+$scope.file.name, false );//true
		//X.setRequestHeader('Content-Type', 'undefined')
		X.send(null);
		if(X.readyState == 4 && X.status != 404){
			var xxx=csvToArray( X.responseText);
			for(var c in xxx){
				alert(xxx[c].name);
				$scope.artwork.name=xxx[c].name;

				/*for(var d in xxx[c]){
		    		alert(xxx[c][d]);
		    	}*/
			}
		}
		return X.responseText;
	}	
});

