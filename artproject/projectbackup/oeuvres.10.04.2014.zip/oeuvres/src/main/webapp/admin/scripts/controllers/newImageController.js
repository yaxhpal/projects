
angular.module('oeuvres').controller('NewImageController', function ($scope, $location, locationParser, ImageResource , ArtworkResource) {
    $scope.disabled = false;
    $scope.image = $scope.image || {};
    
    $scope.artworkList = ArtworkResource.queryAll(function(items){
        $scope.artworkSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.name
            });
        });
    });
    
    $scope.$watch("artworkSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.image.artwork = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            //$location.path('/Images/edit/' + id);
            $location.path("/Images");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ImageResource.save($scope.image, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Images");
    };
});