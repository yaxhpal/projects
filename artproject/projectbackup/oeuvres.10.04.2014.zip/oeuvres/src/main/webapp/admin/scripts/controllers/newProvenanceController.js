
angular.module('oeuvres').controller('NewProvenanceController', function ($scope, $location, locationParser, ProvenanceResource , ArtworkResource) {
    $scope.disabled = false;
    $scope.provenance = $scope.provenance || {};
    
    $scope.artworkList = ArtworkResource.queryAll(function(items){
        $scope.artworkSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.name
            });
        });
    });
    
    $scope.$watch("artworkSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.provenance.artwork = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Provenances/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ProvenanceResource.save($scope.provenance, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Provenances");
    };
});