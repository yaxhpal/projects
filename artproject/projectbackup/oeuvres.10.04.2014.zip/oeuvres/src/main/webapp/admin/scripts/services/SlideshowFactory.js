angular.module('oeuvres').factory('SlideshowResource', function($resource){
    var resource = $resource('../rest/slideshows/:SlideshowId',{SlideshowId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});