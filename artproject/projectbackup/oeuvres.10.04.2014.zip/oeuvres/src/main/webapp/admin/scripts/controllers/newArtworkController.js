
angular.module('oeuvres').controller('NewArtworkController', function ($scope, $location, locationParser, ArtworkResource , CategoryResource, UserResource, ArtistResource) {
    $scope.disabled = false;
    $scope.artwork = $scope.artwork || {};
    $scope.categories=[];
  
    $scope.typeList = CategoryResource.queryAll(function(items){
    	 $scope.typeList = $.map(items, function(item) {
             return ( {
                 value : item,
                 id : item.id,
                 text : item.name,
                 subCat : $.map(item.subCategory, function(i) {
                     return ( {
                         value : i,
                         id : i.id,
                         text : i.name
                     });
                 })
             });
         });
    });
    $scope.$watch("categoriesSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.artwork.categories = [];
            $.each(selection, function(idx,selectedItem) {
            	$scope.artwork.categories.push(selectedItem.id);
            });
        }
    });

    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.firstName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.artwork.user = selection.value;
        }
    });
    $scope.$watch("typeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.artwork.category = selection.id;
        }
    });
    
    $scope.artistList = ArtistResource.queryAll(function(items){
        $scope.artistSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.firstName
            });
        });
    });
    $scope.$watch("artistSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.artwork.artist = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            //$location.path('/Artworks/edit/' + id);
            $location.path("/Artworks");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ArtworkResource.save($scope.artwork, successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Artworks");
    };
});