
angular.module('oeuvres').controller('NewCommentController', function ($scope, $location, locationParser, CommentResource, UserResource, ArtworkResource) {
    $scope.disabled = false;
    $scope.comment = $scope.comment || {};

    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.email
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.comment.author = selection.value;
        }
    });

    $scope.artworkList = ArtworkResource.queryAll(function(items){
        $scope.artworkSelectionList = $.map(items, function(item) {
            return ( {
                value : item,
                text : item.name
            });
        });
    });
    $scope.$watch("artworkSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.comment.artwork = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            //$location.path('/Comments/edit/' + id);
            $location.path("/Comments");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CommentResource.save($scope.comment, successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Comments");
    };
});