
angular.module('oeuvres').controller('NewOrganisationController', function ($scope, $location, locationParser, OrganisationResource ) {
    $scope.disabled = false;
    $scope.organisation = $scope.organisation || {};
    
    $scope.typeList = [
        "ADMIN",
        "GALLARY",
        "PERSONAL",
        "OTHER"
    ];

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            //$location.path('/Organisations/edit/' + id);
            $location.path("/Organisations");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        OrganisationResource.save($scope.organisation, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Organisations");
    };
});