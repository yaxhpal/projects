angular.module('oeuvres').factory('ArtistResource', function($resource){
    var resource = $resource('../rest/artists/:ArtistId',{ArtistId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});