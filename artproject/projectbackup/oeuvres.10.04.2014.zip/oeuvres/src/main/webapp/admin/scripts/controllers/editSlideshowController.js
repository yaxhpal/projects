

angular.module('oeuvres').controller('EditSlideshowController', function($scope, $routeParams, $location, SlideshowResource , UserResource, ArtworkResource) {
    var self = this;
    $scope.disabled = false;

    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.slideshow = new SlideshowResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.email
                    };
                    if($scope.slideshow.user && item.id == $scope.slideshow.user.id) {
                        $scope.userSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
            ArtworkResource.queryAll(function(items) {
                $scope.artworksSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.name
                    };
                    if($scope.slideshow.artworks){
                        $.each($scope.slideshow.artworks, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.artworksSelection.push(wrappedObject);
                            }
                        });
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Slideshows");
        };
        SlideshowResource.get({SlideshowId:$routeParams.SlideshowId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.slideshow);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
            $location.path("/Slideshows");
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.slideshow.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Slideshows");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Slideshows");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.slideshow.$remove(successCallback, errorCallback);
    };

    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.slideshow.user = selection.value;
        }
    });
    $scope.artworksSelection = $scope.artworksSelection || [];
    $scope.$watch("artworksSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.slideshow) {
            $scope.slideshow.artworks = [];
            $.each(selection, function(idx,selectedItem) {
                $scope.slideshow.artworks.push(selectedItem.value);
            });
        }
    });
    $scope.get();
});