

angular.module('oeuvres').controller('EditArtworkController', function($scope, $routeParams, $location, ArtworkResource , CategoryResource, UserResource, ArtistResource) {
    var self = this;
    $scope.disabled = false;
    $scope.categoriesSelection = $scope.categoriesSelection || [];
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.artwork = new ArtworkResource(self.original);
            $scope.typeList = CategoryResource.queryAll(function(items){
              	 $scope.typeList = $.map(items, function(item) {
              		var wrappedObject= {
                           value : item,
                           id : item.id,
                           text : item.name,
                          subCat : $.map(item.subCategory, function(i) {
                               var wrapObj= {
                                   value : i,
                                   id : i.id,
                                   text : i.name
                               };
                        		 if($scope.artwork.category && item.id == $scope.artwork.category.id) {
                        			 if($scope.artwork.categories){
                        				 $.each($scope.artwork.categories, function(idx, element) {
                                           if(i.id == element.id) {
                                               $scope.categoriesSelection.push(wrapObj);
                                           }
                                       });
                        				
                        			}
                               }
                               return wrapObj;
                           })
                       };
              		
              		 if($scope.artwork.category && item.id == $scope.artwork.category.id) {
                         $scope.typeSelection = wrappedObject;
                     }
                     return wrappedObject;
                   
                 });
             });
            
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.email
                    };
                    if($scope.artwork.user && item.id == $scope.artwork.user.id) {
                        $scope.userSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
            ArtistResource.queryAll(function(items) {
                $scope.artistSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        value : item,
                        text : item.firstName
                    };
                    if($scope.artwork.artist && item.id == $scope.artwork.artist.id) {
                        $scope.artistSelection = wrappedObject;
                    }
                    return wrappedObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Artworks");
        };
        ArtworkResource.get({ArtworkId:$routeParams.ArtworkId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.artwork);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
            $location.path("/Artworks");
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.artwork.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Artworks");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Artworks");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.artwork.$remove(successCallback, errorCallback);
    };
    $scope.$watch("typeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.artwork.category = selection.id;
        }
    });
    
    $scope.$watch("categoriesSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.artwork.categories = [];
            $.each(selection, function(idx,selectedItem) {
            	$scope.artwork.categories.push(selectedItem.id);
            });
        }
    });
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.artwork.user = selection.value;
        }
    });
    $scope.$watch("artistSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.artwork.artist = selection.value;
        }
    });

   

    $scope.get();
});