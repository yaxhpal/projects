'use strict';

oeuApp.value('localStorage', window.localStorage);