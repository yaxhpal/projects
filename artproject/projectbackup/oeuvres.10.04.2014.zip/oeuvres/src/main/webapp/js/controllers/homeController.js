'use strict';

oeuApp.controller('homeController', function($scope,dataDelegate,artworks){
	var pageContentObj = $('#pageContent');
	if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
	pageContentObj.removeClass('galleryView');dataDelegate.loadGlobal();
	$('#removeFromSlideshow').css('display','none');
	
	$scope.isInject = true;
	artworks.init();
	if (artworks.items.length>8){
		var newList 	= artworks.items.slice(0);
		$scope.artworks   = _.flatten(newList.toRandom(8));
		newList = null;
	}else{
		$scope.artworks = artworks.items;
	}
});