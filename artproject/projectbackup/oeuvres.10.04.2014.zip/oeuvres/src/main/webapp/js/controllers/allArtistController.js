'use strict';

oeuApp.controller('allArtistController', function($scope, $route, $location,$timeout, artists,artworks,dataDelegate){
	artists.init();artworks.init();dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
	pageContentObj.removeClass('galleryView');$('#removeFromSlideshow').css('display','none');

	var artistsNames = _.uniq(_.sortBy(_.map(_.pluck(artists.items,'lastName'), function(item) { return stripString(item.charAt(0).toUpperCase());}), function(item){ return item;}));
	var pageItem = [];
	_.each(artistsNames, function(browseA){
		pageItem.push('<h2>'+browseA+'</h2>');
		pageItem.push('<div class="carousel">');pageItem.push('<ul class="clearfix">');
		var arts = _.filter(artists.items, function(obj,key){ return obj.lastName.charAt(0).toUpperCase() == browseA;});
		_.each(arts, function(obj,key){
			var subArt=[];
			subArt.push('<li><a href="#/artist/'+obj.id+'">');
			subArt.push('<div class="image" style="background-image:url('+obj.image+');"></div>');
			subArt.push('<h3>'+obj.firstName + ' ' + obj.lastName+'</h3>');
			subArt.push('<span>'+obj.yearOfBirth+'&mdash;'+obj.yearOfDeath+'</span>');
			subArt.push('</a></li>');
			pageItem.push(subArt.join(''));
		});
		pageItem.push('</ul>');pageItem.push('</div>');
	})
	$('#browse').html(pageItem.join(''))
	$('#browse .carousel ul').css('width', function() {
		var itemNo = $(this).children('li').length;
		return itemNo*240+140;
	});
});