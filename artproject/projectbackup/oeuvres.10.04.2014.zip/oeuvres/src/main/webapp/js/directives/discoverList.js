'use strict';

oeuApp.directive('discoverList', ['$cookies','$location','$timeout','$cookieStore', function($cookies,$location,$timeout,$cookieStore){
	return {
		restrict: 'E',
		templateUrl: 'views/discoverList.html',
		scope: {},
		controller: function($scope, artworks){
			artworks.init();
			if (artworks.items.length>8){
				var newList 	= artworks.items.slice(0);
				$scope.artworks   = _.flatten(newList.toRandom(8));
				newList = null;
			}else{
				$scope.artworks = artworks.items;
			}
			$scope.gridTouch = function(){
				/*
				var timenum = 2000;
				var isiPad = navigator.userAgent.match(/iPad/i) != null;
				if (isiPad){
					timenum = 0;
				}
				$timeout(function(){
					setMasonry('#discover .grid ul');
				}, timenum);
				*/
				var $container = $('#discover .grid ul');
				$container.imagesLoaded(function(){
					//FastClick.attach(document.body);
				    gridViewSet();
				});

			};
			$scope.clickMe = function(obj){
				if (obj.id!==undefined && obj.id>0 && !$('#contextMenu').hasClass('isVisible')){
					var vlist = _.pluck($scope.artworks, 'id');
					$cookieStore.put('pageFromHistory',"");
					$cookieStore.put('artworks8only',vlist.join(','));
					$location.path('artwork/'+obj.id);
				}
			};
			$scope.pageForward = function(locat) {
				$location.path(locat);
			};
		},
		link: function($scope,element, attr){
		}
	}
}] );

oeuApp.directive('artworksRenderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
           if ($scope.$last === true) {
                element.ready(function () {
                    $scope.gridTouch();
                });
           }
		}
	};
});