if(!String.prototype.trim) {String.prototype.trim = function () {return this.replace(/^\s+|\s+$/g,'');};}
$(document).ready(function() {
	$('#login input, h1').addClass('isVisible');
	$('#username,#password').bind('focus keypress', function(){
		$('#login p.error.showError').removeClass('showError');
	});
	$('#username,#password').keyup(function(e){if (e.which==13){auto();}});
});
function auto(){
	$('#username,#password').blur();
	var username = $('#username').val();
	var password = $('#password').val();
	if (username.trim() !="" && password!=""){
		var data = {'username': username.trim(), 'password': password.trim()};
		//var url = 'call-api.php?request=/rest/app/login&data='+JSON.stringify(data);
		var url = 'rest/app/login';
		$.ajax({
		  type: "POST",
		  url: url,
		  data: JSON.stringify(data),
		  success: function(d){
		  	try{
			  	if (d!==undefined && d.id>0){
			  		$.session.set('oeuAppUser', JSON.stringify(d));
			  		location.href = 'index.html';
			  	} else {
			  		$('#login p.error').addClass('showError');
			  	}
		  	}catch(e){
		  		$('#login p.error').addClass('showError');
		  	}
		  },
		  contentType: "application/json;charset=utf-8",
		  dataType: "json"
		});
	} else {
		$('#login p.error').addClass('showError');
	}
}