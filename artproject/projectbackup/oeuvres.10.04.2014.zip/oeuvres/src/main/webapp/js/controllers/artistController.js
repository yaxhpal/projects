'use strict';

oeuApp.controller('artistController', function($scope, $route, $location,$timeout, $cookieStore, artists, dataDelegate){
	artists.init();dataDelegate.loadGlobal();

	
	if($('body.searchOpen')){ $('#searchClose').trigger('click'); $('#search .searchBox').blur(); }
	var artist 		= artists.get($route.current.params.artistId);
	var categories 	= null, artworks = null;
	if (typeof artist=='undefined' || artist==null){
		$location.path('/');
	}else{
		_.each(artist.artworks, function(_i){
			_i.artistname = artist.firstName+' '+artist.lastName;
		});
		//categories 		= artists.getCategory(artist.artworks);
		artworks 		= artist.artworks;
		$scope.isInject = true;
		$scope.artist 	= artist;
		$scope.categoies= categories;
		$scope.artworks = artworks;
		var pageContentObj = $('#pageContent');$('#removeFromSlideshow').css('display','none');$('#backBtn').css('display','block');
		if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
		pageContentObj.removeClass('infoView');
	}
	$scope.filterCategory = function(categoryid){
		var arts  = _.filter(artworks, function(obj, key){return _.contains(obj.categories, categoryid);});
		$scope.artworks = arts;$timeout(function(){$(window).resize();},100);
	};
	$scope.setLoading = function(){
		var $container = $('#artistArtworks .grid ul');
		$container.imagesLoaded(function(){
			gridViewSet();
		});

	};
	$scope.gotoPage 			= function(id){
		if (id>0 && !$('#contextMenu').hasClass('isVisible')){
			var vlist = _.pluck($scope.artworks, 'id');
			$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+id);
		}
		
	};
});