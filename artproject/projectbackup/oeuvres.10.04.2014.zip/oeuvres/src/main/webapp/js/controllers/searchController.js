'use strict';

oeuApp.controller('searchController', function($scope,$location,$cookies,$cookieStore,opts){
	$scope.searchtxt 			= '';
	$scope.artworksResult 		= [];
	$scope.artistsResult 		= [];
	$scope.slideshowsResult 	= [];
	$scope.noresult 			= false;
	$scope.isInject = true;
	$scope.$watch('searchtxt', function(){
		var v = stripString($scope.searchtxt.trim().toLowerCase());
		if (v!="" && v.length > 1){
			var searchList 		= v.split(' ');
			$scope.artworksResult = $scope.artworks	= _.filter(artworksGB, function(obj,key){ 
				var nameCP 	= obj.name!=null?obj.name.toLowerCase().split(' '):[];
				var descCP 	= obj.description!=null?obj.description.toLowerCase().split(' '):[];
				var mediCP 	= obj.medium!=null?obj.medium.toLowerCase().split(' '):[];
				/*var locaCP 	= obj.location!=null?obj.location.toLowerCase().split(' '):[];*/
				var deaiCP 	= obj.details!=null?obj.details.toLowerCase().split(' '):[];
				var provCP 	= obj.provenance!=null?obj.provenance.toLowerCase().split(' '):[];
				var counCP 	= obj.country!=null?obj.country.toLowerCase().split(' '):[];
				var townCP 	= obj.town!=null?obj.town.toLowerCase().split(' '):[];
				var housCP 	= obj.house!=null?obj.house.toLowerCase().split(' '):[];
				/*var cateCP 	= obj.categoriesText!=null?obj.categoriesText.toLowerCase().split(' '):[];*/
				var tagsCP 	= obj.tagsText!=null?obj.tagsText.toLowerCase().split(' '):[];
				var artiCP 	= obj.artistname!=null?obj.artistname.toLowerCase().split(' '):[];
				var unionLI = _.union(nameCP,descCP,mediCP,deaiCP,provCP,counCP,townCP,housCP,tagsCP,artiCP);
				var ret = true;
				_.each(searchList, function(sObj,sKey){
					var tlist = _.filter(unionLI, function(sobj,skey){ return stripString(sobj).toLowerCase().indexOf(sObj)>-1;});
					if (tlist.length<1){
						ret=false;
					}
				} );
				return ret;
			});
			$scope.artistsResult  		= _.filter(artistsGB, function(obj,key){ return stripString(obj.firstName).toLowerCase().indexOf(v)>-1 || stripString(obj.lastName).toLowerCase().indexOf(v)>-1;});
			setTimeout(function(){
				$scope.updateGrid();
				$scope.set_width();
			}, 50);
			/*$scope.categoriesResult 	= _.filter(categorysGB, function(obj,key){ return obj.name.toLowerCase().indexOf(v)>-1;});*/
			/*$scope.slideshowsResult 	= _.filter(slideshowsGB, function(obj,key){ return obj.name.toLowerCase().indexOf(v)>-1;});*/
			if ($scope.artworksResult.length<1 && $scope.artistsResult.length<1 && $scope.categoriesResult.length<1 && $scope.slideshowsResult.length<1){
				$scope.noresult = true;
			}else{
				$scope.noresult = false;
			}
		}else{
			$scope.artworks = null;
			if($scope.updateGrid){
				setTimeout(function(){
					$scope.updateGrid();
				}, 10);
			}
			$scope.artworksResult= [];$scope.artistsResult= [];$scope.categoriesResult= [];$scope.slideshowsResult= [];
			$scope.noresult = false;
		}
		opts.updateOption('artworksArr', $scope.artworks);
	},true);
	$scope.closeSearch = function(){
		$scope.searchtxt = '';
		closeSearch();
	}
	$scope.set_width = function(){
		$('#search .carousel ul').css('width', function() {
			var itemNo = $(this).children('li').length;
			return itemNo*240+140;
		});
	};
	$scope.gotoPage 			= function(page,id){
		/*$('#drawerBtnLeft').trigger('click');
		if (page=="artwork"){
			var vlist = _.pluck($scope.artworksResult, 'id');
			//$cookies.artworks8only = vlist.join(',');
			$cookieStore.put('artworks8only',vlist.join(','));
		}*/
		$scope.searchtxt = '';
		$location.path(page+'/'+id);
	};
});