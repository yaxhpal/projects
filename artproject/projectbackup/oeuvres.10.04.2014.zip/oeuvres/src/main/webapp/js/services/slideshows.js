'use strict';

oeuApp.service('slideshows', function($rootScope,dataDelegate){
	this.items 	= dataDelegate.get('slideshows');
	this.once	= false;
	this.init 	= function(){
		if (slideshowsGB.length>0){
			this.items = slideshowsGB;
		}
	}
})