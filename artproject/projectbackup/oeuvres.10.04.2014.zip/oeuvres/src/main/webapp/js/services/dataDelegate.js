'use strict';

oeuApp.service('dataDelegate', function($rootScope, dataService, $http){
	var callbacks = [];
	this.registerCallbacks = function(callback){
		callbacks.push(callback);
	}
	var notifyCallbacks = function(){
		_.each(callbacks, function(_i){
			_i();
		});
	}

	this.loaded = false;
	this.CALLAPI = "";
	if (isDev){
		this.CALLAPI = "call-api.php?request=/";
	}
	
	this.get = function(sname){
		return _.where(dataService.get(), {name: sname})[0].values;
	};
	
	this.getLoaded = function(sname){
		return _.where(dataGB, {name: sname})[0].values;
	};

	var that = this;
	$rootScope.$on('reloadData', function(){
		artworksGB = that.getLoaded('artworks'), artistsGB = that.getLoaded('artists'), slideshowsGB = that.getLoaded('slideshows'), tagsGB = that.getLoaded('tags'); locationsGB = that.getLoaded('locations');
		//that.categorySearchText();that.tagSearchText();that.slideshowSearchText();that.artistSearchText();


		// REMOVE THESE!!!
		var artists = artistsGB;
		_.each(artworksGB, function(obj,key){
			var arts 	= _.find(artists, function(art){ return art.id==obj.artist; });
			if (arts){
				obj.artistname = arts.firstName + ' ' + arts.lastName;
			}else{
				obj.artistname = '';
			}
			arts 	= null;
		});
		artists 	= null;

		var artworks = artworksGB;
		_.each(artistsGB, function(obj,key){
			var arts = _.filter(artworks, function(artObj){return artObj.artist == obj.id;});
			if (arts.length){
				if (obj.hasPhoto){
					obj.image='//bkkr.co/nz/artApp/images/artists/'+obj.id+'.jpg';
				}else{
					var image = (arts[0].images.length)?arts[0].images[0]:'default_artist';
					obj.image = '//bkkr.co/nz/artApp/images/artworks/'+image+'.jpg';
				}
				obj.totalArts = arts.length;
				obj.artworks = arts;
				if (obj.yearOfDeath<1){ obj.yearOfDeath="";}
			}else{
				var image = 'default_artist';
				obj.image = '//bkkr.co/nz/artApp/images/artworks/'+image+'.jpg';
				obj.totalArts = 0;
				obj.artworks = [];
			}
			arts = null;
		});
		artworks = null;
		notifyCallbacks();
	});

	this.loadGlobal = function(force){
		if(!this.loaded || force){
			/*categorysGB = this.get('categories')*/
			artworksGB = this.get('artworks'), artistsGB = this.get('artists'), slideshowsGB = this.get('slideshows'), tagsGB = this.get('tags'); locationsGB = this.get('locations');
			this.loaded = true;
			//this.categorySearchText();this.tagSearchText();this.slideshowSearchText();this.artistSearchText();
			notifyCallbacks();
			//$rootScope.$digest();
		}
	};
	this.saveSlideShow = function(slideid, slidetext, callback){
		var slideshow = {
			id: parseInt(slideid), name: slidetext, userId: siteUser.id
		}
		this.sendPost(this.CALLAPI + 'rest/app/slideshow', slideshow, callback);
		if (isDev){
			this.sendPost(this.CALLAPI + 'rest/app/slideshow&data='+JSON.stringify(slideshow), slideshow, callback);
		}
	};
	this.sendPost = function(url, data, callback){
		$.ajax({
		  type: "POST",
		  url: url,
		  data: JSON.stringify(data),
		  success: function(d){
		  	callback(d);
		  },
		  contentType: "application/json;charset=utf-8",
		  dataType: "json"
		});
	};
	this.attachArtwork = function(artworkid, slideshowid, callback){
		var slideshow = {
			artworkId: parseInt(artworkid), slideshowId: parseInt(slideshowid)
		}
		this.sendPost(this.CALLAPI + 'rest/app/slideshow/addArtwork', slideshow, callback);
		if (isDev){
			this.sendPost(this.CALLAPI + 'rest/app/slideshow/addArtwork&data='+JSON.stringify(slideshow), slideshow, callback);
		}
	};
	this.detachArtwork = function(artworkid, slideshowid, callback){
		var slideshow = {
			artworkId: parseInt(artworkid), slideshowId: parseInt(slideshowid)
		}
		this.sendPost(this.CALLAPI + 'rest/app/slideshow/removeArtwork', slideshow, callback);
		if (isDev){
			this.sendPost(this.CALLAPI + 'rest/app/slideshow/removeArtwork&data='+JSON.stringify(slideshow), slideshow, callback);
		}		
	};
	this.deleteSlideshow = function(slideshowid){
		if (isDev){
			$.ajax({
			    url: this.CALLAPI + 'rest/app/slideshow/'+slideshowid+'&delete=yes',
			    type: 'DELETE',
			    success: function(result) {
			    }
			});
		}else{
			$.ajax({
			    url: this.CALLAPI + 'rest/app/slideshow/'+slideshowid,
			    type: 'DELETE',
			    success: function(result) {
			    }
			});
		}
	};

	this.detachTag = function(artworkid, tagId, callback){
		var slideshow = {
			artworkId: parseInt(artworkid), tagId: parseInt(tagId)
		}
		this.sendPost(this.CALLAPI + 'rest/app/tag/removeArtwork', slideshow, callback);
		if (isDev){
			this.sendPost(this.CALLAPI + 'rest/app/tag/removeArtwork&data='+JSON.stringify(slideshow), slideshow, callback);
		}	
	};
	this.attachTag = function(artworkid, sname, callback){
		var slideshow = {
			tagId:-1,artworkId:parseInt(artworkid),userId:siteUser.id,name:sname
		}
		this.sendPost(this.CALLAPI + 'rest/app/tag/addArtwork', slideshow, callback);
		if (isDev){
			this.sendPost(this.CALLAPI + 'rest/app/tag/addArtwork&data='+JSON.stringify(slideshow), slideshow, callback);
		}	
	};
	this.addComment = function(artworkid, message, callback){
		var comment = {
			id:-1,artworkId:parseInt(artworkid),message:message,authorId:siteUser.id
		}
		this.sendPost(this.CALLAPI + 'rest/app/comment', comment, callback);
		if (isDev){
			this.sendPost(this.CALLAPI + 'rest/app/comment&data='+JSON.stringify(comment), comment, callback);
		}
	};
	this.categorySearchText = function(){
		_.each(artworksGB, function(obj, key){
			obj.categoriesText = _.pluck(_.filter(categorysGB, function(catOjb, catKey){ return _.contains(obj.categories, catOjb.id);   }), "name").join(' ');
		});
	};
	this.tagSearchText = function(){
		_.each(artworksGB, function(obj, key){
			obj.tagsText = _.pluck(_.filter(tagsGB, function(tagobj, tagkey){ return _.contains(tagobj.artworks, obj.id);  } ), "name").join(' ');
		});
	};
	this.slideshowSearchText = function(){
		_.each(artworksGB, function(obj, key){
			obj.slideshowText = _.pluck(_.filter(slideshowsGB, function(tagobj, tagkey){ return _.contains(tagobj.artworks, obj.id);  } ), "name").join(' ');
		});
	};
	this.artistSearchText = function(){
		_.each(artworksGB, function(obj, key){
			var aObj = _.find(artistsGB, function(subobj, key){ return subobj.id == obj.artist; });
			if (aObj!=null){
				obj.artistfullname = aObj.firstName + ' ' + aObj.lastName;
			}
		});
	};

})