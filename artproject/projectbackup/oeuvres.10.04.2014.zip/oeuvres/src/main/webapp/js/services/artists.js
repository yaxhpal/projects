'use strict';

oeuApp.service('artists', function($rootScope,dataDelegate){
	this.items = dataDelegate.get('artists');
	this.once	= false;
	this.init = function(){
		if (!this.once){
			this.once = true;
			var artworks = dataDelegate.get('artworks');
			_.each(this.items, function(obj,key){
				var arts = _.filter(artworks, function(artObj){return artObj.artist == obj.id;});
				if (arts.length){
					if (obj.hasPhoto){
						obj.image='//bkkr.co/nz/artApp/images/artists/'+obj.id+'.jpg';
					}else{
						var image = (arts[0].images.length)?arts[0].images[0]:'default_artist';
						obj.image = '//bkkr.co/nz/artApp/images/artworks/'+image+'.jpg';
					}
					obj.totalArts = arts.length;
					obj.artworks = arts;
					if (obj.yearOfDeath<1){ obj.yearOfDeath="";}
				}else{
					var image = 'default_artist';
					obj.image = '//bkkr.co/nz/artApp/images/artworks/'+image+'.jpg';
					obj.totalArts = 0;
					obj.artworks = [];
				}
				arts = null;
			});
			artworks = null;
		}
	};
	this.get = function(artistid){
		return _.find(this.items, function(obj,key){ return obj.id == artistid;})
	};
	this.getCategory = function(artworks){
		var cates = _.uniq(_.flatten(_.pluck(artworks, 'categories')));
		var data = [], categories = dataDelegate.get('categories');
		_.each(cates, function(i){
			data.push(_.find(categories, function(obj,key){ return obj.id==i;}))
		});
		return data;
	}




})