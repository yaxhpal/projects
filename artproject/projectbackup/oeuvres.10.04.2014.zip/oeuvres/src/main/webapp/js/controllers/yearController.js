'use strict';

oeuApp.controller('yearController', function($scope, $route, $location, $cookieStore, artworks, dataDelegate){
	$('#loading').removeClass('isHidden');
	artworks.init();dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	//if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
	pageContentObj.removeClass('galleryView');$('#removeFromSlideshow').css('display','none');

	var returnYears = function(string, returnType){
		var yearString = string;
		if(yearString.indexOf('Circa')>=0 || yearString.indexOf('circa')>=0){
			yearString = yearString.substring(6);
			console.log('x');
		}
		var yearArray = [];
		yearArray = yearString.split('-');
		console.log(yearArray);
		_.each(yearArray, function(_i, i){
			yearArray[i] = parseInt(_i);
		});
		return yearArray;
	}

	var cid = $route.current.params.yearId;
	if (cid !== undefined && cid!=""){
		/*var yearArr, yearMin, yearMax;
		yearArr = returnYears(cid);
		
		if(yearArr.length <= 0){
			$location.path('/');
		} else if(yearArr.length > 1){
			yearMin = yearArr[0];
			yearMax = yearArr[1];
		} else {
			yearMin = yearArr[0]-3;
			yearMax = yearArr[0]+3;	
		}*/

		$scope.yearTitle = '';
		/*$scope.artworks = _.filter(artworks.items, function(obj, key){ 
			var tYears = returnYears(JSON.stringify(obj.period));
			var fitsYear = false;
			_.each(tYears, function(_i){
				if(_i>=yearMin&&_i<=yearMax){
					fitsYear = true;
				}
			});
			return fitsYear;
		});*/
		$scope.artworks = _.sortBy(artworks.items, function(obj){
			return obj.year;
		});

	}else{
		//$location.path('/');
	}
	$scope.setLoading = function(){
		var $container = $('#artistArtworks .grid ul');
		$container.imagesLoaded(function(){
			$.when(gridViewSet()).then(function(){
				hideLoading();
				pageContentObj.show();
				setTimeout(function(){
					scrollToElement($('#artistArtworks .grid li[year-ref="'+$route.current.params.yearId+'"]:eq(0)'), 'middle', 0);
				}, 100);

				// ADD YEARS
				var fY, lY;
				$container.find('li').each(function(){
					var year = parseInt($(this).attr('year-ref'));
					if((fY!=0 && !fY) || year < fY){
						fY = year;
						console.log(fY);
					}
					if(!lY || year > lY){
						lY = year;
					}
				});
				var diff = 100;
				var nYs = Math.ceil((lY - fY)/diff);
				nYs+=1;
				
				$('#yearNav').html('');
				for(var i = 0; i < nYs; i++){
					$('#yearNav').append('<li><span class="year">'+(fY+(i*diff))+'</span></li>');
				}
				$('#yearNav').append('<div class="cYCont"><div class="cY"></div></div><div class="cYRange"></div>');
				$('#yearNav').css({'margin-top':-(16*(nYs/2))+60});
				$('#yearNav .cYCont').css({'height':(16*nYs)-10})


				$scope.firstYear = fY;
				$scope.lastYear = lY;
				$scope.scrollTO = null;
				$scope.touchTO = null;
				$scope.touched = false;

				$('#yearNav').bind('mousedown', function(){
					if($scope.touchTO){
						clearTimeout($scope.touchTO);
					}
					$scope.touched = true;
					$scope.touchTO = setTimeout(function(){
						$('#yearNav').addClass('touchActive');
					}, 200);
					$(this).addClass('scrollActive');
				});

				$('body').bind('mousemove', function(e){
					if(!$scope.touched){ return; }
					var yNT = $('#yearNav').offset().top;
					var mY = e.pageY;
					var rMY = mY-yNT;
					var maxYNH = ($scope.lastYear-$scope.firstYear)/100*16;
					if(rMY<0){
						rMY = 0;
					} else if(rMY > maxYNH){
						rMY = maxYNH;
					}
					var yearTar = Math.round(rMY/16*100);
					var diff;
					var aYearTar;
					$container.find('li').each(function(){
						var year = parseInt($(this).attr('year-ref'));
						var tDiff = Math.abs(yearTar-year);
						if((diff!=0 && !diff) || tDiff < diff){
							diff = tDiff;
							aYearTar = year;
						}
					});
					scrollToElement($('#artistArtworks .grid li[year-ref="'+aYearTar+'"]:eq(0)'), 'middle', 0);
				});

				$('body').bind('mouseup', function(){
					if(!$scope.touched){ return; }
					if($scope.touchTO){
						clearTimeout($scope.touchTO);
					}
					$('#yearNav').removeClass('touchActive');
					$scope.touched = false;
					$(window).trigger('scroll');
				});

				// BIND SCROLL
				$(window).bind('scroll', function(){

					if($scope.scrollTO){
						clearTimeout($scope.scrollTO);
					}

					$('#yearNav').addClass('scrollActive');

					var fY, lY;
					var fYs = [],
						lYs = [];
					var scrollPos = $(window).scrollTop();
					var windowHeight = $(window).height();
					$container.find('li').each(function(){
						var offsetTop = $(this).offset().top;
						var height = $(this).height();
						if(offsetTop+height>scrollPos){
							fYs.push($(this).attr('year-ref'));
						}
						if(offsetTop+(height/2)<scrollPos+windowHeight){
							lYs.push($(this).attr('year-ref'));
						}
					});
					_.each(fYs, function(_i){
						if(!fY || _i < fY){
							fY = _i;
						}
					});
					_.each(lYs, function(_i){
						if(!lY || _i > lY){
							lY = _i;
						}
					});
					var yNH = (lY-fY)/100*16;
					var yFP = fY/100*16;
					$('#yearNav .cY').css({'height': yNH, 'top':yFP})

					var yearRangeHtml = fY+' - '+lY;
					if(fY==lY){
						yearRangeHtml = fY;
					}
					$('#yearNav .cYRange').html(yearRangeHtml).css({'top':yFP+(yNH/2)});

					$scope.scrollTO = setTimeout(function(){
						if(!$scope.touched){
							$('#yearNav').removeClass('scrollActive');
						}
					}, 500);

				});
				
			});
		});
	};
	$scope.gotoPage 			= function(id){
		if (id>0 && !$('#contextMenu').hasClass('isVisible')){
			var vlist = _.pluck($scope.artworks, 'id');
			$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+id);
		}
		
	};
	$scope.pageForward = function(locat) {
		$location.path(locat);
	};
});

oeuApp.directive('categoryallRenderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
           if ($scope.$last === true) {
                element.ready(function () {
                    $scope.setLoading();
                });
           }
		}
	};
});