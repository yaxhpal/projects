'use strict';

oeuApp.controller('tagController', function($scope, $route,$location,$cookieStore, artworks, tags,dataDelegate){
	$('#loading').removeClass('isHidden');
	artworks.init();tags.init();dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	//if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
	pageContentObj.removeClass('galleryView');$('#removeFromSlideshow').css('display','none');
	var cid = $route.current.params.tagId;
	if (cid !== undefined && cid!="" && cid>0){
		var tag 	= _.find(tags.items, function(obj, key){ return obj.id == cid;});
		if (tag!==undefined && tag.id>0){
			$scope.tagTitle = tag.name;
			$scope.artworks = _.filter(artworks.items, function(obj, key){ return _.contains(tag.artworks, obj.id);});
		}else{
			$location.path('/');
		}
	}else{
		$location.path('/');
	}
	$scope.setLoading = function(){
		var $container = $('#artistArtworks .grid ul');
		$container.imagesLoaded(function(){
			$.when(gridViewSet()).then(function(){
				hideLoading();
				pageContentObj.show();
			});
		});
	};
	$scope.gotoPage 			= function(id){
		if (id>0 && !$('#contextMenu').hasClass('isVisible')){
			var vlist = _.pluck($scope.artworks, 'id');
			$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+id);
		}
		
	};
	$scope.pageForward = function(locat) {
		$location.path(locat);
	};
});

oeuApp.directive('categoryallRenderFinish', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
           if ($scope.$last === true) {
                element.ready(function () {
                    $scope.setLoading();
                });
           }
		}
	};
});