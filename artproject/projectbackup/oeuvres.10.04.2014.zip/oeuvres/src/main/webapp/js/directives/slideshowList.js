'use strict';

oeuApp.directive('slideshowList', function($timeout, $location, $route, $compile, dataDelegate,$rootScope){
	return {
		restrict: 'E',
		templateUrl: 'views/slideshows.html',
		scope: {},
		controller: function($scope){
			
			var updateSlideshows = function(){
				$scope.slideshows = slideshowsGB;
				setTimeout(function(){
					$scope.bindSwipe();
				},100);
			}

			dataDelegate.registerCallbacks(updateSlideshows);

			var removeSlideshow = function(e){
				e.stopPropagation();
				var target = e.target;
			    if (!$(target).is('.deleteSlideshow') && !$(target).is('.deleteSlideshow')) {
				    $('.deleteSlideshow').remove();
				};
				$(document).off('click', removeSlideshow);
			}

			$scope.bindSwipe = function(){
				$('#drawerRight .menu li').swipe('destroy');
				$('#drawerRight .menu li').swipe({
					tap: function(event){
						event.preventDefault();
						var el;
						if(!$('body').hasClass('hasTouch')){
							$('#drawerRight .menu li').swipe('disable');
							$('#drawerRight .menu li').swipe('enable');
							el = event.toElement;
						} else {
							el = event.target;
						}
						if($(el).hasClass('deleteSlideshow')){
							$(this).slideUp(200, function() {$(this).remove();});
							var slideid = $(this).attr('data-ref');slideid = slideid.replace('slideshow','');
							if (slideid>0){
								dataDelegate.deleteSlideshow(slideid);
								$scope.$apply(function(){
									slideshowsGB = _.filter(slideshowsGB, function(obj, key){ return obj.id != slideid;});
									$scope.slideshows = slideshowsGB;
									if($route.current.params && slideid==$route.current.params.id){
										$location.path('/');
									}
									setTimeout(function(){
										$scope.bindSwipe();
									},100);
								});
							}
							$('.deleteSlideshow').remove();
						} else {
							if(!$(this).find('input').length){
								var sid = $(this).attr('data-ref');
								$scope.slideClick(sid);
							}
						}
						return false;
					},
					hold: function(event){
						$scope.inputBind(this);
					},
					swipeLeft: function(event){
						var sid = $(this).attr('data-ref');
					    if (sid>0){
					    	$(this).append('<a href="#" class="deleteSlideshow" id="'+sid+'">Delete</a>');
					    }
						$(document).on('click', removeSlideshow);
					},
					threshold: 50,
					longTapThreshold: 300,
					excludedElements: 'button, input, select, textarea, .noSwipe',
					allowPageScroll: 'vertical'
		        });
			}

			$scope.inputBind = function(t){
				$('.drawer').addClass('iOsFix');
				$('.deleteSlideshow').remove();
				$('#drawerRight .menu').find('li').each(function(){
					var oldtxt = $('input',this).val();
					$('input',this).remove();$('a',this).html(oldtxt).show();
				});
				var currentName = $('a', t).html(),slideid = $('a', t).attr('id'), that = t;
				$('a', t).hide();
				$(t).append('<input type="text" value="'+currentName+'">');
				var currentField = $('input', t);
				currentField.blur(function() {
					$scope.saveSlide(slideid, $(this).val(), this);
				}).keydown(function(e){
					var v = $(this).val().trim();
					if (v=="New Slideshow"){$(this).val('');}
					if (e.which==13 && v!=""){
						$scope.saveSlide(slideid, $(this).val(), this);
					}
				});
				currentField.focus();
			}

			$scope.saveSlide = function(sid, stext, ts){
				var liObj = $(ts).closest('li'), postflag = true;
				sid = sid.replace('slideshow','');
				if (sid>0){
					var oldSS = _.find(slideshowsGB, function(obj,key){ return obj.id == sid;});
					if (oldSS.name == stext.trim()){
						postflag = false;
					}
					$('.deleteSlideshow',liObj).remove();$('input',liObj).remove();$('a',liObj).html(stext).show();
				}else{
					liObj.html('<a href="#">'+stext+'</a>');
				}
				if (postflag){
					dataDelegate.saveSlideShow(sid, stext,function(d){
						var slideScope = angular.element($('#menuSlideshow')).scope();
						slideScope.$apply(function(){
							if (sid>0){
								for (var i=0;i<slideshowsGB.length;i++){
									if (slideshowsGB[i].id==d.id){
										slideshowsGB[i].name = d.name;
										setTimeout(function(){
											$scope.bindSwipe();
										},100);
										break;
									}
								}
							}else{
								slideshowsGB.push(d);
								$(liObj).remove();
								setTimeout(function(){
									$scope.bindSwipe();
								},100);
							}
						});
					});
				}
			};

			$scope.slideClick = function(ts){
				var slideid = ts;
				if (slideid!==undefined && slideid>0){
					if (globalArtworkid>0){
						$('.deleteSlideshow').remove();
						dataDelegate.attachArtwork(globalArtworkid, slideid, function(d){
							$rootScope.$apply(function(){
								for (var i=0;i<slideshowsGB.length;i++){
									if (slideshowsGB[i].id==d.id){
										slideshowsGB[i] = d;
										setTimeout(function(){
											$scope.bindSwipe();
										},100);
										break;
									}
								}
							});
						});
						var ssObj = _.find(slideshowsGB, function(obj,key){ return obj.id == slideid;});
						var slideshowTitle = ssObj.name;
						$('#slideshow'+slideid).addClass('selected');
						setTimeout(function() {$('#drawerRight .menu li a').removeClass('selected');}, 100);
						setTimeout(closeDrawers, 250);
						showAlert('addedToSlideshow', slideshowTitle);
					}else{
						closeme();
						$scope.$apply(function(){
							$location.path('browse/slideshow/'+slideid);
						})
					}
				}
			};
		},
		link: function($scope,element, attr){
			
			$('#addSlideshow').click(function(e) {
				e.preventDefault();
				$('.deleteSlideshow').remove();
				dataDelegate.saveSlideShow(-1, 'New Slideshow',function(d){
					var slideScope = angular.element($('#menuSlideshow')).scope();
					slideScope.$apply(function(){
						slideshowsGB.push(d);
						setTimeout(function(){
							$scope.bindSwipe();
							$('#menuSlideshow > li').last().each(function(){
								$scope.inputBind(this);
							});
						},100);
					});
				});
			});	

		}

	}
} );