'use strict';

oeuApp.controller('objectController', function($rootScope,$scope, $route, $location,$cookies,$cookieStore,$compile, $timeout, artworks,dataDelegate, tags, slideshows, opts){
	
	artworks.init();
	//categories.init();
	tags.init();
	dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	if (!$('#loading').hasClass('isHidden') || $('#initLoading').length){
		hideLoading();
		$('#pageContent').fadeIn('slow');
	}
	pageContentObj.removeClass('galleryView').addClass('infoView');
	$('#backBtn').css('display','block');
	$('#galleryCounter').css('display','block');
	var pageHistory = $cookieStore.get('pageFromHistory');
	var detachslideshow = -1;
	var detachObj = null;
	if (pageHistory!==undefined && pageHistory!= null && pageHistory!="" && pageHistory!="empty"){
		$('#removeFromSlideshow').css('display','block');
		$cookieStore.put('pageFromHistory',"");
		var tmpObj = JSON.parse(pageHistory);
		detachslideshow = tmpObj.slideshow;
		detachObj = _.find(slideshows.items, function(obj, key){ return obj.id == detachslideshow;});
	}else{
		$('#removeFromSlideshow').css('display','none');
	}

	if($('body.searchOpen')){ $('#searchClose').trigger('click'); $('#search .searchBox').blur(); }

	var aid = $route.current.params.artworkId;
	var artobj = null;
	if (aid!==undefined && aid!=null && aid>0){
		artobj = _.find(artworks.items, function(obj, key){return obj.id==aid;});
	}
	if (artobj==null){
		$location.path('/');
	}

	/*var categoryList = _.filter(categories.items, function(obj, key){ return _.contains(artobj.categories, obj.id);});
	artobj.categoryList = categoryList;*/
	$scope.setupArtworkObj = function(artobj){
		var tagList = _.filter(tags.items, function(obj, key){ return _.contains(obj.artworks, artobj.id);});
		artobj.tagList = tagList;
		var artslist = _.filter(artworks.items, function(obj, key){
			return obj.artist == artobj.artist && obj.id != artobj.id;
		});
		artobj.artList = artslist;
		var exhibitions = dataDelegate.get('exhibitions');
		var exbiList = _.filter(exhibitions, function(obj, key){ return _.contains(artobj.exhibitions, obj.id); });
		artobj.exhibitionsList = exbiList;
		var locationList = dataDelegate.get('locations');
		var location = _.find(locationList, function(obj){
			return obj.id==artobj.locationId;
		});
		location.url = location.location+'&country='+location.country;
		artobj.location = location;
		var similar = [];
		var similarLength = 4;
		var similarConditions = [
			function(obj){ return obj.artist==artobj.artist; },
			function(obj){ return obj.medium==artobj.medium; },
			function(obj){ return obj.category==artobj.category; }
		];
		// SIMILAR
		_.each(similarConditions, function(func){
			if(similar.length < similarLength){
				_.each(artworks.items, function(obj){
					if(similar.length < similarLength && obj.id!=artobj.id && !_.find(similar, function(_i){ return _i.id == obj.id }) && func(obj)){
						similar.push(obj);
					}
				});
			}
		});
		artobj.similarPieces = similar;
		return artobj;
	}
	
	$scope.artwork = globalAWS = $scope.setupArtworkObj(artobj);

	/*var pagearts = [];
	$scope.artworks = [];
	var artworks8only = $cookieStore.get('artworks8only');
	if (artworks8only!==undefined && artworks8only!=null && artworks8only!=""){
		var vlist = artworks8only.split(',');
		for (var i=0;i<vlist.length;i++){
			var vobj = _.find(artworks.items, function(obj, key){return obj.id==vlist[i];});
			pagearts.push(vobj);
		}
		$cookieStore.put('artworks8only',"");
	}else{
		pagearts.push(artobj);
	}
	var exhibitions = dataDelegate.get('exhibitions');
	for (var i=0;i<pagearts.length;i++){
		var categoryList = _.filter(categories.items, function(obj, key){ return _.contains(pagearts[i].categories, obj.id);});
		pagearts[i].categoryList = categoryList;
		var tagList = _.filter(tags.items, function(obj, key){ return _.contains(obj.artworks, pagearts[i].id);});
		pagearts[i].tagList = tagList;
		var artslist = _.filter(artworks.items, function(obj, key){
			return obj.artist == artobj.artist && obj.id != artobj.id;
		});
		pagearts[i].artList = artslist;
		var exbiList = _.filter(exhibitions, function(obj, key){ return _.contains(pagearts[i].exhibitions, obj.id); });
		pagearts[i].exhibitionsList = exbiList;
	}
	globalAWS = pagearts;
	var listToPage = [], startPoint = -1;
	startPoint = _.indexOf(_.pluck(pagearts, 'id'), aid*1);
	if (pagearts.length>5){
		globalPointer = startPoint;
		listToPage = getList(globalPointer);
		startPoint = 2;
	}else{
		listToPage = pagearts;
	}
	showPointer = startPoint + 1;
	$scope.artworks = listToPage;
	$scope.setSlide 	= function(){
		artwork_slideshow_init(startPoint, 'gallery', $scope);
		infoImageSize();attachArtworkEvents($scope);
	};*/

	$scope.resizeTO = null;

	$scope.hasRendered = function(init){
	
		$scope.imgHeld = false;


		$scope.$grid = $scope.$el.find('ul:eq(0)');
		$scope.$grid.isotope({});

		$scope.resize();
		$(window).on('resize', $scope.resize);
		
		/*$('#pageContent .furtherInfo').find('.purchasePrice, .valuation, .insuranceValue, .importTax, .sourcedBy, .purchasedFrom, .commission, .artistRR, .condition, .exhbitions, .provenance, .importExport, .files > ul').each(function(){
			var html = $.trim($(this).text());
			if(html == ''){
				$(this).html('—');
			}
		});*/

		$('#gallery img').swipe({
	      	tap: function(event) { $scope.viewToggle(); },
	        hold:function(event) { $scope.slideshowTrigger(); },
	        longTapThreshold: 300,
	        allowPageScroll: 'vertical',
	        swipeStatus:function(event, phase, direction, distance, duration, fingers){
	        	if(phase=='end'){
	        		setTimeout(function(){
		        		$scope.imgHeld = false;
		        	}, 500);
	        	}
	        }
	    });

	    attachArtworkEvents($scope);

	   $('#pageContent').imagesLoaded(function(){
	    	$scope.resize();
	    })

	   /*if(init){
	   		if(opts.options.fromSlideshow){
				$('#pageContent').removeClass('infoView').addClass('galleryView');
				dynamicHeights();
				$scope.viewListener();
				$scope.$on('$destroy', function(){
					opts.updateOption('fromSlideshow', false);
				});
			}
	   } */

	}

	$scope.removeTag = function(artwordid, tagid, loopByAngular){
		dataDelegate.detachTag(artwordid, tagid, function(d){
			$rootScope.$apply(function(){
				if (!loopByAngular){
					$('#artTag'+artwordid+'-'+tagid).remove();
				}
				var tagIndex = -1;
				for (var i=0;i<tags.items.length;i++){
					if (tags.items[i].id==d.id){
						tagIndex = i;
						tags.items[i].artworks = d.artworks;
						break;
					}
				}
				if (tagIndex<0){
					tags.items.push(d);
				}
/*
				if (d.length>0){
					for (var i=0;i<tags.items.length;i++){
						if (tags.items[i].id==tagid){
							tags.items[i].artworks = d.artworks;
							break;
						}
					}
				}else{
					var tagIndex = -1;
					for (var i=0;i<tags.items.length;i++){
						if (tags.items[i].id==tagid){
							tagIndex = i;break;
						}
					}
					tags.items.splice(tagIndex,1);
				}
				*/
				$scope.updateTagsGlobal();
			});
		});
	};
	$scope.addTag = function(artid, newTag, that, waction, currentTags, loopByAngular){
		dataDelegate.attachTag(artid, newTag, function(d){
			$rootScope.$apply(function(){
				var list1Updated = false;
				_.each(tags.items, function(obj, key){
					if (obj.id==d.id){
						obj.artworks = d.artworks;
						list1Updated = true;
					}
				});				
				if (!list1Updated){ tags.items.push(d); }
				if (waction=="add" || waction=="attach"){
					$scope.updateTagsGlobal();
					if (!loopByAngular){
						var newTagStr = newTag;
						if (currentTags>0){
							newTagStr = ', ' + newTagStr;
						}
						if (waction=="add" || waction=="attach"){
							$('<li id="artTag'+artid+'-'+d.id+'"><a class="tagName" href="" artwordid="'+artid+'" data-ref="'+d.id+'">'+newTagStr+'</a></li>').insertBefore($(that).parent('li'));
						}
					}
				}
			});
		});
	};
	$scope.addComment = function(artid, comment, that, submitByAngular){
		comment = comment.replace(/\r\n|\r|\n/g,"<br />");
		dataDelegate.addComment(artid, comment, function(d){
			$rootScope.$apply(function(){
				for (var i=0;i<artworks.items.length;i++){
					if (artworks.items[i].id==artid){
						artworks.items[i].comments.push({
							id:d.id, message: d.message, date: d.date, authorId:d.authorId, author:d.author
						});
						if (!submitByAngular){
							//$(that).parent().parent().find('.artworkCommentsTotal').html('('+artworks.items[i].comments.length+')');
							//$(that).parent().find('ul').append('<li><p>'+d.message+'</p><p class="author">'+d.author+' <span class="timestamp">'+new Date(d.date).format('h:MM, d mmmm yyyy')+'</span></p></li>');
						}
						break;
					}
				}
			});
		});		
	};
	$scope.removeArtworkFromSlideshow = function(artid){
		dataDelegate.detachArtwork(artid, detachslideshow, function(d){
			$rootScope.$apply(function(){
				for (var i=0;i<slideshowsGB.length;i++){
					if (slideshowsGB[i].id==detachslideshow){
						slideshowsGB[i].artworks = d.artworks;
						break;
					}
				}
			});
		});
		var slideshowTitle = detachObj.name;
		setTimeout(function() {$('#drawerRight .menu li a').removeClass('selected');}, 100);
		setTimeout(closeDrawers, 250);
		showAlert('removeedToSlideshow', slideshowTitle);
	};
	$scope.gotoPage 			= function(id){
		if (id>0 && !$('#contextMenu').hasClass('isVisible')){
			//var vlist = _.pluck($scope.artworks, 'id');
			//$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+id);
		}
		
	};
	$scope.updateTagsGlobal = function(){
		//for (var i=0;i<globalAWS.length;i++){
		//	var tagList = _.filter(tags.items, function(obj, key){ return _.contains(obj.artworks, globalAWS[i].id);});
		//	globalAWS[i].tagList = tagList;
		//}
		var tagList = _.filter(tags.items, function(obj, key){ return _.contains(obj.artworks, globalAWS.id);});
		globalAWS.tagList = tagList;
	};
	$scope.hasImportExport = function(obj){
		var showme = false;
		if ((obj.importRestriction=="" || obj.importRestriction==null) && (obj.exportRestriction=="" || obj.exportRestriction==null)){
			showme = true;
		}
		return showme;
	};
	$scope.conditionText = function(obj){
		var txt = '';
		if (obj.conditionCode!="" && obj.conditionCode!=null && obj.conditionDescription!="" && obj.conditionDescription!=null){
			txt = obj.conditionCode + ', ' + obj.conditionDescription;
		}else{
			if (obj.conditionCode!="" && obj.conditionCode!=null){
				txt = obj.conditionCode;
			}else if (obj.conditionDescription!="" && obj.conditionDescription!=null){
				txt = obj.conditionDescription;
			}
		}
		return txt;
	};
	$scope.stringToLower = function(string){
		var lS = string.toLowerCase();
		return lS;
	};

	$scope.resize = function(){
		dynamicHeights();

		if($scope.resizeTO){ clearTimeout($scope.resizeTO); }
		$scope.resizeTO = setTimeout(function(){
			var gW = $scope.$grid.width();
			var imgWidth = Math.floor(gW/100*24.4);
			$scope.$grid.find('li').each(function(){
				var $img = $('img', this);
				var w = $img.attr('img-w');
				var h = $img.attr('img-h');
				var ratio = h/w;
				$(this).css({'width': imgWidth, 'height': imgWidth*ratio});
			});
			$scope.$grid.isotope('reLayout');
			dynamicHeights();
		}, 300);
	};

	$scope.viewToggle = function() {
		
		if(!$scope.imgHeld){
			$('#pageContent').toggleClass('galleryView infoView');
			dynamicHeights();
			$scope.viewListener();	

		return false;
		}
	}
	
	
	$scope.slideshowTrigger = function() {

		if($('body').hasClass('hasTouch')){
			$scope.imgHeld = true;
		} else {			
			$("#gallery img").swipe('disable');
			$("#gallery img").swipe('enable');
		}
		
		var selection = $scope.artwork.id;
		
		if ($('#pageContent').hasClass('infoView')) {
				
			addToSlideshow(selection);
			
		} else if ($('#pageContent').hasClass('galleryView')) {
				
			$('#pageContent').toggleClass('galleryView infoView');
	    	dynamicHeights();
			$scope.viewListener();				
			
			setTimeout(function() {
				addToSlideshow(selection)
				}, 400);
			}
				
		return false;
		
	}

	$scope.viewListener = function() {
		dynamicHeights();
		setTimeout(function() {
			if($('#pageContent').hasClass('galleryView')) {
				$('.drawerBtn, #search').addClass('hidden');
				$('#gallery').html('');
				var artworkArr = [];
				var startSlide;
				var aws = opts.options.artworksArr;
				if(!aws || aws.length < 2 || !_.findWhere(aws, {id: $scope.artwork.id})){
					aws = artworks.items;
				}
				$scope.awsLog = aws;
				_.each(aws, function(obj, i){
					if(obj.id==$scope.artwork.id){
						startSlide = i;
					}
					artworkArr.push({imgURL: 'http://bkkr.co/nz/artApp/images/artworks/'+obj.images[0].id+'h.jpg', height: obj.images[0].height});
				});
				startSlide+=1;
				$('#gallery img').swipe('disable');
				$("#gallery").slidr({
					'arr': artworkArr,
					'startAt': startSlide,
					'click': true,
					'touch': true,
					'$scope': $scope,
					'pagination': false,
					'counter': false
				});
			} else {
				$('.drawerBtn, #search').removeClass('hidden');
			}
		}, 400);
	}

	$scope.refresh = function(c){
		var c = c-1;
		$timeout(function(){
			$scope.artwork = globalAWS = $scope.setupArtworkObj($scope.awsLog[c]);
			$('#gallery').html('<img src="//bkkr.co/nz/artApp/images/artworks/'+$scope.artwork.images[0].id+'h.jpg" h="'+$scope.artwork.images[0].height+'">').attr('style', '');
			dynamicHeights();
			$scope.viewToggle();
			setTimeout(function(){
				$scope.$grid.isotope('destroy');
				$scope.$grid = $('#pageContent').find('.similarPieces ul');
				$('#gallery').removeClass('slidr');
				$scope.hasRendered();
			
			}, 100);
		});
	};
});

oeuApp.directive('objectRender', function(){
	return {
		restrict: 'A',
		link: function($scope, element, attr){
			$scope.$el = $(element);
			$scope.$grid = $scope.$el.find('.similarPieces ul');
           	element.ready(function () {
                $scope.hasRendered(true);
            });

           $scope.$on('$destroy', function(){
           		$(window).off('resize', $scope.resize);
				$('#pageContent').removeClass('infoView galleryView');
				$('#gallery img').swipe('destroy');
			});
       }
	};
});