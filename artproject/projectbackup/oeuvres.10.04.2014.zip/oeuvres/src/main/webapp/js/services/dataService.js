'use strict';
var services = angular.module('services', []);
var DATAENDPOINT = 'rest/app/'+siteUser.id;
if (isDev){
	DATAENDPOINT = 'call-api.php?request=/rest/app/'+siteUser.id;
	//DATAENDPOINT = 'data.json';
}
services.factory('dataService', function(localStorage, $http, $rootScope){
	var data 	= null;
	var promise;

	if(hasLocalStorage && localStorage.getItem('data') !== null){
		data = JSON.parse(localStorage.getItem('data'));
		$http.get(DATAENDPOINT).success(function(d){
			dataGB = d;
			console.log(dataGB);
			$rootScope.$broadcast('reloadData');
			if(hasLocalStorage){
				localStorage.setItem('data', JSON.stringify(d));
			}
		});
	} else {
		promise = $http.get(DATAENDPOINT).success(function(d){
			data = d;
			if(hasLocalStorage){
				localStorage.setItem('data', JSON.stringify(d));
			}
		});
	}
	return {
		promise: promise,
		get: function(){
			return data;
		}
	}
});
