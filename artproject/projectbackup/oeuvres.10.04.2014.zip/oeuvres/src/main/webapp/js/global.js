/*
	Author:
	Thom Dorkings
	(bkkr.co)
*/


//DOM-READY EVENT ------------------------------------------------------------
var moved = false, touchStartX=0, touchStartY=0, viewportWidth=0, viewportHeight=0;
var imgHeld;
var currentPosition = null;
$(document).ready(function() {

	//GLOBAL VARIABLES ---------------------------
	viewportWidth	=	$(window).width(); // gets the viewport width
	viewportHeight	=	$(window).height();// gets the viewport height

	//DETECT TOUCH DEVICES ------------------------------------------------------------

	if (navigator.userAgent.indexOf('Android') >= 0 ||
      	navigator.userAgent.indexOf('iPhone') >= 0 ||
      	navigator.userAgent.indexOf('iPad') >= 0 ||
      	navigator.userAgent.indexOf('iPod') >= 0) {
			$('body').addClass('hasTouch');
			$('body').on('touchstart', function(e) {
				moved = false;
				touchStartX = event.touches[0].pageX;
				touchStartY = event.touches[0].pageY;
				});
			$('body').on('touchmove', function(e) {
			    //if finger moves more than 20px set moved to true
			    if (Math.abs(event.touches[0].pageX - touchStartX) > 20 ||
			        Math.abs(event.touches[0].pageY - touchStartY) > 20) {
			            moved = true;
						}

				if(window.navigator.standalone && (event.touches[0].pageX - touchStartX) > 20 && touchStartX < 10) {
					
					goBack();
					
					}
				
				});
	    };


	//REMOVE CLICK EVENT DELAY (close INIT) ---------------------------

//	FastClick.attach(document.body);


	//DRAWER BUTTONS ---------------------------

	$('#drawerBtnLeft').click(function() {
			var pageContent = $('#pageContent');
			if (pageContent.length && pageContent.hasClass('galleryView')){
				pageContent.toggleClass('galleryView infoView');galleryHeight();
			}
			if($('#container').hasClass('openLeft')) {
				closeDrawers();
			} else {
				toggleLeft();
			};

			return false;

		});

	$('#drawerBtnRight').click(function() {
			var pageContent = $('#pageContent');
			if (pageContent.length && pageContent.hasClass('galleryView')){
				pageContent.toggleClass('galleryView infoView');galleryHeight();
			}
			if($('#container').hasClass('openRight')) {
				closeDrawers();
			} else {
				toggleRight();
			};

			return false;

		});


	//SEARCH ---------------------------

	$('#search .searchBox').focus(function() {openSearch();});

	$('#search .close').click(function(e) {e.preventDefault();closeSearch();});
	$('#pageContent').click(function(e) {
		if($('#container').hasClass('openLeft') || $('#container').hasClass('openRight')) {
			closeDrawers();
		}
	});

	$('.mask').unbind('click').click(function() {
		$('#container').removeClass('hasPopup');
		$('.popup').removeClass('isVisible');
	});
		
		
	//MENU SHOW/HIDE ---------------------------
	oe.Menu.init();

	//remove it later
		$('.editTags').click(function() {
			hideContextMenu();
			$('#container').addClass('hasPopup');
			$('#editTagPopup').addClass('isVisible');
			return false;
			});

	//TOGGLE PRIVACY ---------------------------
	
	var privacyMode = true;
	
	$('#privacy').on('click', function() {
		
		if(privacyMode == false) {
			privacyMode = true;
			//$('.private').toggle();
			$('body').addClass('privacyHidden');
			$('.icon', this).text('F');
		} else if(privacyMode == true) {
			privacyMode = false;
			//$('.private').toggle();
			$('body').removeClass('privacyHidden');
			$('.icon', this).text('G');
		}
		
		closeDrawers();
		
		return false;
		});

	$('#logOut').on('click', function(e){
		e.preventDefault();
		$.session.set('oeuAppUser', '');
		if(hasLocalStorage){
			localStorage.removeItem('user');
			localStorage.removeItem('data');
		}
		location.href = "login.html";
	});


});

function goBack(){
	//e.preventDefault();
	history.go(-1);
}

function stripString(str){
	var rExps=[
		{re:/[\xC0-\xC6]/g, ch:'A'},
		{re:/[\xE0-\xE6]/g, ch:'a'},
		{re:/[\xC8-\xCB]/g, ch:'E'},
		{re:/[\xE8-\xEB]/g, ch:'e'},
		{re:/[\xCC-\xCF]/g, ch:'I'},
		{re:/[\xEC-\xEF]/g, ch:'i'},
		{re:/[\xD2-\xD6]/g, ch:'O'},
		{re:/[\xF2-\xF6]/g, ch:'o'},
		{re:/[\xD9-\xDC]/g, ch:'U'},
		{re:/[\xF9-\xFC]/g, ch:'u'},
		{re:/[\xD1]/g, ch:'N'},
		{re:/[\xF1]/g, ch:'n'}
	];

	for(var i=0, len=rExps.length; i<len; i++)
	str=str.replace(rExps[i].re, rExps[i].ch);

	return str;
}

function gridViewSet(){
	//GRID VIEW (ISOTOPE MASONRY INIT) ---------------------------

      var $container = $('.objectContainer > ul');
      setMasonryLazy($container);
      
      $container.isotope({
        itemSelector: 'li'
      });
      


	//GRID VIEW (TAPHOLD CONTEXTUAL MENU) ---------------------------

	/*$('.grid ul li').on("taphold", {duration: 300}, function(e)
		{
			if($('body').hasClass('hasTouch')) {
				posX = touchStartX;
				posY = touchStartY;
			} else {
				posX = e.pageX;
				posY = e.pageY;
			};
			var selection = $(this);

		    showContextMenu(selection);
		    $('body').on('touchend', function(e) {
		    	e.preventDefault();
				if(moved == true) {
					hideContextMenu();
					}
					return false;
				});

			$(document).click(function(e) {
			    var target = e.target;

			    if (!$(target).is('#contextMenu a') && !$(target).is('#contextMenu')) {
			        hideContextMenu();
			    	};
			});

		})
		.on("click", function(e)
		{
			 e.preventDefault();
			if ($('#contextMenu').hasClass('isVisible')) {
			        hideContextMenu();
			       
			    	};
		}); */
}


//WINDOW RESIZE EVENT ---------------------------

$(window).resize(function() {
		fixOverPage();
});

$(window).resize(function() {
    /* if(this.resizeTO) clearTimeout(this.resizeTO);
    this.resizeTO = setTimeout(function() {
		      var $container = $('.grid ul');
		      setMasonryLazy($container);
    }, 500);*/
});



//SCROLL EVENT ------------------------------------------------------------

$(window).scroll(function() {

    var scrollPosition = $(window).scrollTop();
    
    if(scrollPosition > 80) {
	    $('#search').addClass('solid');
    	} else {
	    $('#search').removeClass('solid');
    	}

});

	function fixOverPage(){
		viewportWidth	=	$(window).width(); // updates the viewport width
		viewportHeight	=	$(window).height();// updates the viewport height
		fixOverflow();
	}

//DRAWERS ---------------------------

	function toggleLeft() {
		$('#container').removeClass('openRight').addClass('openLeft');
		hideContextMenu();
		};

	function toggleRight() {
		$('#container').removeClass('openLeft').addClass('openRight');
		hideContextMenu();
		};

	function closeDrawers() {
		$('#container').removeClass('openLeft').removeClass('openRight');
		hideContextMenu();
		globalArtworkid = 0;
		globalArtworkidDelete = 0;
		//closeSearch();
		$('.deleteSlideshow').remove();
		};

	/* SEARCH */

	function openSearch() {
		$('body').addClass('searchOpen');
		currentPosition = $(window).scrollTop();
		$(window).scrollTop(0);
		};

	function closeSearch() {
		$('body').removeClass('searchOpen');
		$('#search .searchBox').val('');
		if(currentPosition){
			$(window).scrollTop(currentPosition);
			currentPosition = null;
		}
		return false;
		};



//DRAWER OVERFLOW FIX (ORIENTATION BUG IN iOS) ---------------------------

	function setOverflow(){
	    $('.drawer').css({webkitOverflowScrolling: 'touch', overflow: 'auto'});
		};

	function fixOverflow(){
	    $('.drawer').css({webkitOverflowScrolling: 'auto', overflow: 'hidden'});
	    setTimeout(setOverflow,10);
		};


//DYNAMICALLY SET CAROUSEL WIDTH DEPENDENT ON No. OF ITEMS ---------------------------

	function setCarouselWidth() {
		$('.carousel ul').css('width', function() {
			var itemNo = $(this).children('li').length;
			return itemNo*240+140;
			});
		};


//GRID VIEW - CONTEXT MENU ---------------------------

	function showContextMenu(selection) {
		var artworkid = $(selection).attr('data-ref');
		$('#addToSlideshow,#addTag,#addComment,#removeFromSlideshow').attr('data-ref', artworkid);
		$('.grid ul li').removeClass('focus').addClass('blur');
		$(selection).addClass('focus');
		$('#contextMenu').css({'left':posX-30, 'top':posY-120}).addClass('isVisible');
		};

	function hideContextMenu() {
		globalArtworkid = 0;globalArtworkidDelete = 0;
		$('.grid ul li').removeClass('focus').removeClass('blur');
		$('#contextMenu').removeClass('isVisible');
		}

	function galleryHeight() {
		$('#pageContent').css('min-height', viewportHeight);
		$('#pageContent.galleryView .galleryContainer .slides li, #pageContent.galleryView .galleryContainer .slides li .artwork').css('height', viewportHeight);
		$('#pageContent.infoView .galleryContainer .slides li, #pageContent.infoView .galleryContainer .slides li .artwork').css('height', 'auto');
		}

	function setOverflowContainer(){
	    $('#container').css({webkitOverflowScrolling: 'touch', overflow: 'auto'});
		};

	function fixOverflowContainer(){
	    $('#container').css({height: $(window).height()});
		};
	function hideLoading() {
		setTimeout(function() {
			if($('#initLoading').length){
				$('#initLoading').remove();
			}
			$('#loading').addClass('isHidden');
		}, 400);
	};

	var globalAWS = [],globalPointer=0, showPointer=1;
	function getList(artIndex,direction){
		var artIndexF1 = 0,artIndexF2 = 0,artIndexB1 = 0, artIndexB2 = 0;
		artIndexF1 = artIndex - 1;
		if (artIndexF1<0){artIndexF1 = globalAWS.length-1;}

		artIndexF2 = artIndexF1 - 1;
		if (artIndexF2<0){artIndexF2 = globalAWS.length-1;}

		artIndexB1 = artIndex + 1;
		if (artIndexB1>=globalAWS.length){artIndexB1 = 0;}

		artIndexB2 = artIndexB1 + 1;
		if (artIndexB2>=globalAWS.length){artIndexB2 = 0;}
		var ret = [];
		ret.push(globalAWS[artIndexF2],globalAWS[artIndexF1],globalAWS[artIndex],globalAWS[artIndexB1],globalAWS[artIndexB2]);
		
		return ret;
	};
	function createNew(direction,oldDiv,$scope){
		if (direction=="next"){
			globalPointer += 3;
		}else{
			globalPointer -= 3;
		}
		if (globalPointer>=globalAWS.length){ globalPointer = globalPointer - globalAWS.length; }
		if (globalPointer<0){ globalPointer = globalPointer + globalAWS.length; }
		var newList = getList(globalPointer,direction);

		var divname = "gallery"+Math.floor(Math.random() * (9999 - 1000 + 1)) + 1000;
		var newcont = '<div id="'+divname+'" class="galleryContainer"><ul class="slides">';
		for (var i=0;i<newList.length;i++){
			newcont += createLI(newList[i]);
		}
		newcont += '</ul></div>';

		$.when($('#'+oldDiv).after(newcont).remove()).then(function(){
			setTimeout(function(){
				$('#artworkloading').hide();
				if (direction=="next"){
					artwork_slideshow_init(2,divname,$scope);
				}else{
					artwork_slideshow_init(2,divname,$scope);
				}
				infoImageSize();attachArtworkEvents($scope);
			},1000);
		});	
		
	}

	function createLI (artwork){
		var content = [];
		content.push('<li class="slide" data-status="new" data-ref="'+artwork.id+'"> <!-- Artwork -->');
		content.push('		<div class="artwork" style="background-image:url(//bkkr.co/nz/artApp/images/artworks/'+artwork.images[0]+'h.jpg)" data-ref="'+artwork.id+'">');
		content.push('			<img src="//bkkr.co/nz/artApp/images/artworks/'+artwork.images[0]+'h.jpg">');
		content.push('		</div>');
		content.push('		<div class="artworkInfo">');
		content.push('			<div class="tier1">');
		content.push('				<h2 class="artist"><a href="#/artist/'+artwork.artist+'">'+artwork.artistname+'</a></h2>');
		content.push('				<h3 class="title">'+artwork.name+'</h3>');
		content.push('				<p class="origin">'+artwork.period+', '+artwork.country+'</p>');
		content.push('				<p class="medium">'+artwork.medium+'</p>');
		content.push('				<p class="dimensions">'+artwork.widthCm+' &times; '+artwork.heightCm+'cm</p>');
		content.push('				<ul class="categories">');
		var categoryIndex = 0;
		_.each(artwork.categoryList, function(category, key){
			var categoryTmp = '<span>, </span>';
			if (categoryIndex==0){categoryTmp="";}
			content.push('<li><a href="#/category/'+category.id+'">' + categoryTmp +category.name+'</a></li>');
			categoryIndex += 1;
		});
		content.push('				</ul>');
		content.push('				<p class="era"><a href="javascript:return false;">'+artwork.era+'</a></p>');
		content.push('				<p class="artworkid">');
		content.push('					<span class="accno">'+artwork.accountNumber+'</span> / <span class="tagno">'+artwork.tagNumber+'</span>');
		content.push('				</p>');
		content.push('				<ul class="tags">');
		content.push('					<li><span class="icon">3</span></li>');
		var tagIndex = 0;
		_.each(artwork.tagList, function(tag, key){
			var tagTmp = '<span>, </span>';
			if (tagIndex==0){tagTmp="";}
			content.push('<li data-ref="'+tag.id+'" artwordid="'+artwork.id+'" id="artTag'+artwork.id+'-'+tag.id+'"><a href="#/tag/'+tag.id+'" artwordid="'+artwork.id+'" data-ref="'+tag.id+'">'+tagTmp+tag.name+'</a></li>');
			tagIndex += 1;
		});
		content.push('					<li><a class="editTags" href="#" artwordid="'+artwork.id+'">EDIT TAGS</a></li>');
		content.push('				</ul>');
		content.push('				<p class="location">');
		content.push('					<span class="icon">A</span>');
		content.push('					<a href="#">Magnolia, New York</a>');
		content.push('					<a class="relocate" href="#">RELOCATE</a>');
		content.push('				</p>');
		content.push('			</div>');
		content.push('			<div class="tier2">');
		content.push('				<div class="artworkDetails">');
		content.push('					<div class="description"><p>'+artwork.description+'</p></div>');

		var conditiontxt = "";
		if (artwork.conditionCode!="" && artwork.conditionCode!=null && artwork.conditionDescription!="" && artwork.conditionDescription!=null){
			conditiontxt = artwork.conditionCode + ', ' + artwork.conditionDescription;
		}else{
			if (artwork.conditionCode!="" && artwork.conditionCode!=null){
				conditiontxt = artwork.conditionCode;
			}else if (artwork.conditionDescription!="" && artwork.conditionDescription!=null){
				conditiontxt = artwork.conditionDescription;
			}
		}
		if (conditiontxt!=""){
			content.push('					<div class="slideOut condition">');
			content.push('						<h4><span class="icon">6</span> Condition</h4>');
			content.push('						<div class="slideOutInner">');
			content.push('							<p>'+conditiontxt+'</p>');
			content.push('						</div>');
			content.push('					</div>');	
		}
		if (artwork.provenances.length>0){
			content.push('					<div class="slideOut provenance">');
			content.push('						<h4><span class="icon">6</span> Provenance</h4>');
			content.push('						<div class="slideOutInner">');
			content.push('							<ol>');
			_.each(artwork.provenances, function(provenance, key){
				content.push('<li><span class="date">'+provenance.date+'</span><span class="owner">'+provenance.owner+'</span></li>');
			});
			content.push('							</ol>');
			content.push('						</div>');
			content.push('					</div>');
		}
		if (artwork.exhibitionsList.length>0){
			content.push('					<div class="slideOut exhibitions">');
			content.push('						<h4><span class="icon">6</span> Exhibition History</h4>');
			content.push('						<div class="slideOutInner">');
			content.push('							<ol>');
			_.each(artwork.exhibitionsList, function(exhibition, key){
				content.push('<li><span class="date">'+exhibition.date+'</span><span class="name">'+exhibition.name+'</span></li>');
			});
			content.push('							</ol>');
			content.push('						</div>');
			content.push('					</div>');			
		}
		content.push('					<div class="slideOut purchase">');
		content.push('						<h4><span class="icon">6</span> Purchase Information</h4>');
		content.push('						<div class="slideOutInner">');
		content.push('							<table>');
		var afprice = (artwork.price==null)?'':artwork.price;
		var afpurchasedDate = (artwork.purchasedDate==null)?'':'('+artwork.purchasedDate+')';
		var afvat = (artwork.vat==null)?'':artwork.vat;
		var afvaluation = (artwork.valuation==null)?'':artwork.valuation;
		var afvaluationDate = (artwork.valuationDate==null)?'':'('+artwork.valuationDate+')';
		var afinsurance = (artwork.insurance==null)?'':artwork.insurance;
		var afsource = (artwork.source==null)?'':artwork.source;
		var afcommission = (artwork.commission==null)?'':artwork.commission;
		var afpurchasedFrom = (artwork.purchasedFrom==null)?'':artwork.purchasedFrom;
		content.push('								<tr><td><h5>Price</h5></td><td>'+afprice+' <span class="date">'+afpurchasedDate+'</span></td></tr>');
		content.push('								<tr><td><h5>VAT</h5></td><td>'+afvat+'</td></tr>');
		content.push('								<tr><td><h5>Valuation</h5></td><td>'+afvaluation+' <span class="date">'+afvaluationDate+'</span></td></tr>');
		content.push('								<tr><td><h5>Insured for</h5></td><td>'+afinsurance+'</td></tr>');
		content.push('								<tr><td><h5>Sourced by</h5></td><td>'+afsource+'</td></tr>');
		content.push('								<tr><td><h5>Commission</h5></td><td>'+afcommission+'</td></tr>');
		content.push('								<tr><td><h5>Purchased from</h5></td><td>'+afpurchasedFrom+'</td></tr>');
		content.push('							</table>');
		content.push('						</div>');
		content.push('					</div>');
		content.push('					<div class="slideOut importexport">');
		content.push('						<h4><span class="icon">6</span> Import/Export</h4>');
		content.push('						<div class="slideOutInner">');
		if ((artwork.importRestriction=="" || artwork.importRestriction==null) && (artwork.exportRestriction=="" || artwork.exportRestriction==null)){
			content.push('							<p>There are no import/export restrictions on this item.</p>');
		}else{
			if (artwork.importRestriction!="" && artwork.importRestriction!=null){
				content.push('							<p>'+artwork.importRestriction+'</p>');
			}
			if (artwork.exportRestriction!="" && artwork.exportRestriction!=null){
				content.push('							<p>'+artwork.exportRestriction+'</p>');
			}		
		}

		content.push('						</div>');
		content.push('					</div>');
		if (artwork.documents.length>0){
			content.push('					<div class="slideOut documents">');
			content.push('						<h4><span class="icon">6</span> Documents <span class="count">('+artwork.documents.length+')</span></h4>');
			content.push('						<div class="slideOutInner">');
			content.push('							<ul>');
			_.each(artwork.documents, function(document, key){
				content.push('<li>'+document.name+' <a href="//static.oeuvr.es/docs/'+artwork.id+'/'+document.file+'" target="_blank"><span class="filetype">'+document.type+'</span></a></li>');
			});
			content.push('							</ul>');
			content.push('						</div>');
			content.push('					</div>');
		}


		content.push('					<div class="slideOut comments">');
		content.push('						<h4><span class="icon">6</span> Comments <span class="count artworkCommentsTotal">('+artwork.comments.length+')</span></h4>');
		content.push('						<div class="slideOutInner">');
		content.push('							<ul>');

		_.each(artwork.comments, function(comment, key){
			content.push('<li><p>'+comment.message+'</p><p class="author">'+comment.author+' <span class="timestamp">'+comment.date+'</span></p></li>');
		});

		content.push('							</ul>');
		content.push('							<form artwordid="'+artwork.id+'">');
		content.push('								<textarea class="newComment" placeholder="Add Comment" rows="5"></textarea>');
		content.push('								<input type="submit" class="submit">');
		content.push('							</form>');
		content.push('						</div>');
		content.push('					</div>');
		content.push('				</div>');
		content.push('				<div class="moreFromArtist">');
		if (artwork.artList.length>0){
			content.push('					<h4>MORE FROM THIS ARTIST</h4>');
		}
		content.push('					<ul>');
		_.each(artwork.artList, function(artObj, key){
			content.push('<li><a href="#/artwork/'+artObj.id+'"><img src="//bkkr.co/nz/artApp/images/artworks/'+artObj.images[0]+'.jpg"></a></li>');
		});
		content.push('					</ul>');
		content.push('				</div>');
		content.push('			</div>');
		content.push('		</div>');
		content.push('</li> <!-- END - Artwork -->');

		return content.join('');
	};

	function getArtworkById(artid){
		return _.find(globalAWS, function(obj, key){ return obj.id == artid;});
	}
	var artworkPageScopeOnly = null;
	function removeTag(tagid, artwordid, that, loopByAngular){
		if (tagid>0 && artwordid>0){
			artworkPageScopeOnly.removeTag(artwordid,tagid,loopByAngular );
			$('.mask').trigger('click');
		}
	}

	function updateArtworkTagsPanel(artworkObject,loopByAngular){
		var tagsLi = [], yourTags = [];
		_.each(artworkObject.tagList, function(obj, key){
			tagsLi.push('<li>'+obj.name+' <a href="" class="removeTag" onclick="removeTag('+obj.id+','+artworkObject.id+', this, '+loopByAngular+');return false;">REMOVE</a></li>');
			yourTags.push(obj.id);
		});
		$('#artworkTagsList').html(tagsLi.join(''));

		var addTagsLi = ['<option value="disabled" class="disabled">+ Add a Tag</option>'];
		_.each(tagsGB, function(obj, key){
			if (!_.contains(yourTags, obj.id)){
				addTagsLi.push('<option value="'+obj.id+'">'+obj.name+'</option>')
			}
		});
		addTagsLi.push('<option value="createNewTag">Create New Tag</option>');
		$('#artworkTagsAdd').html(addTagsLi.join(''));
		return yourTags;
	}

	function attachArtworkEvents($scope){
		var isTagTaphold = false;
		$('#pageContent .artworkInfo .tier2 .artworkDetails .slideOut h4').click(function() {
			$(this).parent('.slideOut').toggleClass('open');
		});
		$('#pageContent .comments').find('form').submit(function(event) {
			event.preventDefault();
			var artid = $(this).attr('artwordid');
			var comment = $(this).find('textarea').val().trim();
			if (artid>0 && comment !=""){
				var submitByAngular = $(this).find('.submit').hasClass('submitByAngular');
				$scope.addComment(artid, comment, this, submitByAngular);
				$(this).find('textarea').val('');
			}
		});

		$('#removeFromSlideshow').unbind('click').click(function(e){
			e.preventDefault();
			var artid = $(this).attr('data-ref');
			$scope.removeArtworkFromSlideshow(artid);
			return false;
		});
		artworkPageScopeOnly = $scope;
		//POPUPS	
		$('#pageContent .editTags').unbind('click').click(function(e) {
			e.preventDefault();
			var thisObj = this;
			var subArtId = $(this).attr('artwordid');
			$('#newTag').hide();
			hideContextMenu();
			var loopByAngular = $(this).hasClass('editTagsByAngular');
			if (!isNaN(subArtId) && subArtId>0){
				var artworkObject = $scope.artwork;
				var yourTags = updateArtworkTagsPanel(artworkObject,loopByAngular);
				$('#artworkTagsAdd').unbind('change').change(function(){
					if ($(this).val()=="createNewTag"){
						$('#newTag').val('');
						$('#newTag').show().focus();
					}else{
						$('#newTag').hide();
					}
				});
				$('#artworkTagsSubmit').unbind('click').click(function(){
					var newTag = "", waction="add";
					if ($('#artworkTagsAdd').val()!="disabled" && $('#artworkTagsAdd').val()!="createNewTag"){
						newTag = $('#artworkTagsAdd option[value="'+$('#artworkTagsAdd').val()+'"]').text();
						waction = "attach";
					}else if ($('#artworkTagsAdd').val()=="createNewTag"){
						newTag = $('#newTag').val().trim();
					}
					if (newTag!=""){
						$scope.addTag(subArtId, newTag, thisObj,waction, yourTags.length, loopByAngular);
					}
					$('.mask').trigger('click');
				});

				$('#container').addClass('hasPopup');
				$('#editTagPopup').addClass('isVisible');
			}
		});

		//RELOCATE ---------------------------

		$('.relocate').click(function() {
			$('#container').addClass('hasPopup');
			$('#relocatePopup').addClass('isVisible');


			$('#artworkRelocateSubmit').unbind('click').click(function(){
				$('.mask').trigger('click');
			});
			return false;
		});


	}

	function artwork_slideshow_init(currentArt, divname, $scope){
		var gotoSlide = 0;
		if (currentArt>0){
			gotoSlide = currentArt;
		}
		$('#'+divname).flexslider({
		    animation: "slide",
		    keyboard: true,
		    controlNav: false,
			directionNav: false,
			slideshow: false,
			startAt: gotoSlide,
			animationLoop: true,
			pauseOnHover: false,
			start: function(slider) {
				slider.numberSlider = globalAWS.length;
				galleryHeight();
				viewListener();
				galleryCounter(slider);
				},
			before: function(slider) {
				if (slider.numberSlider>5){
					if (slider.direction=="prev" && slider.currentSlide==0){
						if ($('#pageContent').hasClass('galleryView')){
							$('#artworkloading').css('background-color','#000');
							$('#artworkloading').removeClass('whiteloading').addClass('blackloading').show();
						}else{
							$('#artworkloading').css('background-color','#fff');
							$('#artworkloading').removeClass('blackloading').addClass('whiteloading').show();
						}
						createNew(slider.direction,divname, $scope);
					}else if (slider.direction=="next" && slider.currentSlide==4){
						if ($('#pageContent').hasClass('galleryView')){
							$('#artworkloading').css('background-color','#000');
							$('#artworkloading').removeClass('whiteloading').addClass('blackloading').show();
						}else{
							$('#artworkloading').css('background-color','#fff');
							$('#artworkloading').removeClass('blackloading').addClass('whiteloading').show();
						}
						createNew(slider.direction,divname, $scope);
					}
				}
				if (slider.direction=="prev"){
					showPointer -= 1;
				}else{
					showPointer += 1;
				}
				if (showPointer>globalAWS.length){ showPointer = 1; }
				if (showPointer<1){ showPointer = globalAWS.length; }

				hideContextMenu();
				slideInView = slider.currentSlide;
				galleryCounter(slider);
				showGalleryCounter();
				},
			after: function(slider) {
				hideGalleryCounter();
				}
		});

		artworkSet('#artworkSlide .artwork');

		$(window).resize(function() {
				galleryHeight();
				infoImageSize();
		});
	}

	function artworkSet(sid){

	/*$('.galleryContainer .artwork img').on("taphold", {duration: 300}, function(e)
		{

			if($('body').hasClass('hasTouch')) {
				posX = touchStartX;
				posY = touchStartY;
			} else {
				posX = e.pageX;
				posY = e.pageY;
			};

			var selection = $(this);

			if($('#pageContent').hasClass('infoView')) {
				 showContextMenu(selection);
				 }

		    $('body').on('touchend', function(e) {
				if(moved == true) {
					hideContextMenu();
					}
				});

			$(document).click(function(e) {
			    var target = e.target;

			    if (!$(target).is('#contextMenu a') && !$(target).is('#contextMenu')) {
			        hideContextMenu();
			    	};
			});

		})
		.on("click", function(e)
		{
			if ($('#contextMenu').hasClass('isVisible')) {
			        hideContextMenu();
			        e.preventDefault();
			    	} else {
			    	$('#pageContent').toggleClass('galleryView infoView');
			    	infoImageSize();
					viewListener();
					galleryHeight();
			    	};
		});*/
	}

	Array.prototype.toRandom = function(n) {
	    var ret = [];
	    for(var i=0;i<n;i++) {
	      ret.push(this.splice(Math.random()*this.length,1));
	    }
	    return ret;
	};

	function closeme(){
		if($('#container').hasClass('openLeft') || $('#container').hasClass('openRight')) {
			closeDrawers();
		}
	}
	function viewListener() {
		if($('#pageContent').hasClass('galleryView')) {
				$('.drawerBtn, #backBtn').addClass('isHidden');
			} else {
				$('.drawerBtn, #backBtn').removeClass('isHidden');
			}
		}
	var globalArtworkid = 0, globalArtworkidDelete = 0;
	$('#addToSlideshow').click(function() {
		globalArtworkid = $(this).attr('data-ref');
		addToSlideshow();
		return false;
		});

	//ADD TO SLIDESHOW ---------------------------

	function addToSlideshow(id) {
		globalArtworkid = id;
		$('#contextMenu').removeClass('isVisible');
		$('#container').removeClass('openLeft').addClass('openRight');
		}



//ALERTS ---------------------------

	function showAlert(type, variable) {

		if(type == 'addedToSlideshow') {
			$('#alert p').text('Artwork succesfully added to '+variable+'.');
			}
		if(type == 'removeedToSlideshow') {
			$('#alert p').text('Artwork succesfully removed from '+variable+'.');
			}
		$('#alert').addClass('isVisible');
		setTimeout(function() {$('#alert').removeClass('isVisible');}, 1600);

		}

	function setMasonry(sname){
		$(sname).masonry({ itemSelector: 'li'});
	}

	function setMasonryLazy(fname){
		var $grid = $(fname);
		/*
		$container.imagesLoaded(function(){
		    $container.masonry({
		        itemSelector: '.',
		        columnWidth: function(containerWidth){
		        	console.log(containerWidth)
		            return containerWidth / 12;
		        }
		    });
		    $('.grid img').lazyload({
		        effect: 'fadeIn',threshold : 50
		    });
		    $('.grid img').trigger('scroll');
		});
*/
		if ( $grid.length > 0) {
				$grid.imagesLoaded( function() {
					$grid.delay(200).isotope({
						//gutterWidth: 14,
						//itemSelector: '.inner',
						//isAnimated: false,
						//isFitWidth: true,
						//columnWidth: 194,
						//animationOptions: { duration: 400 }
					});
				    $('.grid img').lazyload({
				        effect: 'fadeIn',threshold : 50
				    });
				    $('.grid img').trigger('scroll');
				});

		}
	}

	// DYNAMIC HEIGHTS ON OBJECT PAGE

	var panelPadding = 60;

	function dynamicHeights() {

		//Gallery
		$('#pageContent').css('min-height', viewportHeight);
		$('.galleryView').css('height', viewportHeight);
		$('.infoView').css('height', 'auto');
		
		if ($('#pageContent').hasClass('infoView')) {
				$('.infoView #gallery').css('max-height', viewportHeight*0.55);
				$('.infoView #gallery img').css({'padding-top': ''});
			} else {
				$('.galleryView #gallery').css('max-height', viewportHeight);
				$('.galleryView #gallery').css('height', viewportHeight);
				$('.galleryView #gallery img').each(function(){
					var h = $(this).attr('h');
					if(h<viewportHeight){
						$(this).css({'padding-top': (viewportHeight-h)/2});
					}
				});
			}
		
		if($('#pageContent').hasClass('infoView')) {
			
			//Primary	
			var galleryHeight = $('#gallery').height();
			$('.primary').css('min-height', galleryHeight);
			
			//Description	
			$('.objectDesc').height('auto');	
				
			var leftHeight = $('.secondary .left').height();
			var currentDescHeight = $('.secondary .right').height();
			var newDescHeight = Math.max(leftHeight, currentDescHeight);
			
			$('.objectDesc').height(newDescHeight-(panelPadding*2));
			
			//Files
			$('.files').height('auto');
			
			var commentHeight = $('.discussions .left').height();
			var currentFilesHeight = $('.discussions .right').height();
			var newFilesHeight = Math.max(commentHeight, currentFilesHeight);
			
			$('.files').height(newFilesHeight-(panelPadding*2));
			
			}
		
	}

	function infoImageSize() {
		var infoImageHeight = viewportHeight/2;
		if ($('#pageContent').hasClass('infoView')) {
			$('#pageContent.infoView .galleryContainer .slides li .artwork, #pageContent.infoView .galleryContainer .slides li .artwork img').css('max-height', infoImageHeight);
		} else { 
			$('#pageContent.galleryView .galleryContainer .slides li .artwork, #pageContent.galleryView .galleryContainer .slides li .artwork img').css('max-height', '');
		}
	}


	function scrollToTop(slider) {
		if (slideInView != slider.currentSlide && $('body').scrollTop() != 0) {
			$('body').animate({'scrollTop':'0'}, 600, 'easeInOutExpo');
			}
		}

	function scrollToElement($el, pos){
		var $el = $el;
		if($el.length){
			var top = $el.offset().top;
			if(pos == 'middle'){
				var height = $el.height();
				top -= (viewportHeight-height)/2;
			}
			$('body, html').scrollTop(top);
		}
	}

	// FitText on features carousel headings ---------------------------

	function fitFeatureHeadings() {
		$("#features .copyArea h2").fitText(0.8, { minFontSize: '36px', maxFontSize: '60px' });
		}


	function galleryCounter(slider) {
		var thisSlide = slider.animatingTo + 1;
		var totalSlides = slider.numberSlider;
		$('#galleryCounter').html(showPointer+'/'+totalSlides);
		$('#galleryCounter').css('color','grey')
		}

	function showGalleryCounter() {
		$('#galleryCounter').addClass('isVisible');
		}

	function hideGalleryCounter() {
		$('#galleryCounter').removeClass('isVisible');
		}

	function localStorageTest(){
	var mod = 'test';
	try {
        localStorage.setItem(mod, mod);
        localStorage.removeItem(mod);
        return true;
    } catch(e) {
        return false;
    }
}
		