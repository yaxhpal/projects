'use strict';

oeuApp.service('tags', function($rootScope,dataDelegate){
	this.items 	= dataDelegate.get('tags');
	this.once	= false;
	this.init 	= function(){
		if (!this.once){
			this.once	= true;
		}
	}
})