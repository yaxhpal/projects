'use strict';

oeuApp.controller('allCategoryController', function($scope, $route, $location,$timeout,$cookieStore, categories,artworks,artists,dataDelegate){
	$('#loading').removeClass('isHidden');
	categories.init();artworks.init();artists.init();dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	pageContentObj.removeClass('galleryView').removeClass('infoView');
	pageContentObj.hide();
	$('#removeFromSlideshow').css('display','none');
	_.each(artworks.items, function(obj, key){
		var artist = artists.get(obj.artist);
		if (artist!==undefined && artist!=null){
			obj.artistname = artist.firstName + ' ' + artist.lastName;
		}
	});
	$scope.categories= categories.items;
	$scope.artworks = artworks.items;
	$scope.filterCategory = function(categoryid){
		var arts  = _.filter(artworks.items, function(obj, key){return _.contains(obj.categories, categoryid);});
		var $container = $('#artistArtworks .grid ul');
	    $container.isotope('destroy');
	    $scope.artworks = arts;
	};
	$scope.setLoading = function(){
		var $container = $('#artistArtworks .grid ul');
		$container.imagesLoaded(function(){
			$.when(gridViewSet()).then(function(){/*callback function*/
				/*
$.when($('#loading').addClass('isHidden')).then(function(){
					pageContentObj.fadeIn('slow');
				});
*/
			hideLoading();
			pageContentObj.show();

			});
			//$.when($container.masonry()).then(function(){/*callback function*/hideLoading();});
		});

	};
	$scope.gotoPage 			= function(id){
		if (id>0 && !$('#contextMenu').hasClass('isVisible')){
			var vlist = _.pluck($scope.artworks, 'id');
			$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+id);
		}
		
	};
	$scope.pageForward = function(locat) {
		$location.path(locat);
	};
});