'use strict';

oeuApp.controller('slideshowController', function($rootScope,$scope, $route,$location,$cookies,$cookieStore, artworks, slideshows,dataDelegate){
	$('#loading').removeClass('isHidden');
	artworks.init();slideshows.init();dataDelegate.loadGlobal();
	var pageContentObj = $('#pageContent');
	//if (!$('#loading').hasClass('isHidden')){hideLoading();$('#pageContent').fadeIn('slow');}
	pageContentObj.removeClass('galleryView');
	var sid = $route.current.params.slideshowId;
	var slideshow = null;
	if (sid !== undefined && sid!="" && sid>0){
		slideshow 	= _.find(slideshows.items, function(obj, key){ return obj.id == sid;});
		if (slideshow!==undefined && slideshow!=null && slideshow.id>0){
			$scope.categoryTitle = slideshow.name;
			$scope.artworks = _.filter(artworks.items, function(obj,key){ return _.contains(slideshow.artworks, obj.id); });
			if ($scope.artworks.length<1){
				hideLoading();
			}
		}else{
			$location.path('/');
		}
	}else{
		$location.path('/');
	}
	
	$scope.setLoading = function(){
		var $container = $('#artistArtworks .grid ul');
		$container.imagesLoaded(function(){
			$.when(gridViewSet()).then(function(){
				hideLoading();
				pageContentObj.show();
			});
		});
		$('#removeFromSlideshow').css('display','block').unbind('click').click(function(e){
			e.preventDefault();
			var artid = $(this).attr('data-ref');
			
			dataDelegate.detachArtwork(artid, sid, function(d){
				$rootScope.$apply(function(){
					for (var i=0;i<slideshowsGB.length;i++){
						if (slideshowsGB[i].id==sid){
							slideshowsGB[i].artworks = d.artworks;
							break;
						}
					}
				});
			});

			var removeMe = $('#artworkli'+artid);
			removeMe.addClass('removed');
			setTimeout(function() {
				removeMe.remove();setTimeout(function(){
					$container.isotope( 'reLayout' , function(){});
				}, 200);
				}, 400);
			hideContextMenu();

			//var slideshowTitle = slideshow.name;
			//setTimeout(function() {$('#drawerRight .menu li a').removeClass('selected');}, 100);
			//setTimeout(closeDrawers, 250);
			//showAlert('removeedToSlideshow', slideshowTitle);
			//if ($('#artworkli'+artid).length){$('#artworkli'+artid).remove();}
			return false;
		});
	};
	$scope.gotoPage = function(obj){
		if (obj !== undefined && obj !==null && obj.id>0 && !$('#contextMenu').hasClass('isVisible')){
			$cookieStore.put('pageFromHistory',JSON.stringify({slideshow:sid}));
			var vlist = _.pluck($scope.artworks, 'id');
			//$cookies.artworks8only = vlist.join(',');
			$cookieStore.put('artworks8only',vlist.join(','));
			$location.path('artwork/'+obj.id);
		}
	};
	$scope.pageForward = function(locat) {
		$location.path(locat);
	};
});


